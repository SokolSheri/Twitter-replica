
<br><br><br>
<?php

include('dbh.php');
session_start();

$active=$_SESSION['userid'];
$posty = $_POST['postId'];

$sqlL ="SELECT * FROM posts WHERE postid = $posty;";
$resultL = mysqli_query($conn,$sqlL);
$count = mysqli_num_rows($resultL);
$rowL=mysqli_fetch_assoc($resultL);

$retweetsL="SELECT * FROM retweets WHERE userid=$active AND postid=$posty;";
$retweetsR = mysqli_query($conn,$retweetsL);
$countRt = mysqli_num_rows($retweetsR);




if($countRt <= 0){
$rt=$rowL['msg']."ID=".$posty;
$rtnum=$rowL['rts']+1;

$sqlI = "INSERT INTO posts (userid,msg,likes,rts) VALUES ('$active','$rt',0,0)";
    $resultI = mysqli_query($conn,$sqlI);
    
$incr ="UPDATE posts SET rts=$rtnum WHERE postid=$posty;";
$ri = mysqli_query($conn,$incr);

$insRts ="INSERT INTO retweets (userid,postid) VALUES ('$active','$posty')";
$resultRt = mysqli_query($conn,$insRts);

}else{

$rtnum=$rowL['rts']-1;

$delRt ="DELETE FROM retweets WHERE userid=$active AND postid=$posty;";
$dResult =mysqli_query($conn,$delRt);

$decr ="UPDATE posts SET rts=$rtnum WHERE postid=$posty;";
$di = mysqli_query($conn,$decr);

$allposts ="SELECT * FROM posts WHERE userid=$active;";
$allResults = mysqli_query($conn,$allposts);


$compy = "ID=".$posty;
$nPos = $posty+1;

if(mysqli_num_rows($allResults)>0){
    while($row=mysqli_fetch_assoc($allResults)){

$stry = $row['msg'];
$newStr=substr($stry,strrpos($stry,"I"));
$newP= "ID=".$posty;
if($newStr==$compy){
    $delPost ="DELETE FROM posts WHERE userid=$active AND msg LIKE '%$newP';";
    $dpResult =mysqli_query($conn,$delPost);
}
    }
}

}

    

?>





