<?php
include('mainInclude.php');


$file= $_FILES['file'];

echo $file['name'];
move_uploaded_file($file['tmp_name'],"uploads/".$file['name']);

//header('Location:othersPage.php?profVal='.$_POST['profile'].'/');
?>

