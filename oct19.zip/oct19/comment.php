<html>
<?php
include('dbh.php');
session_start();
$active=$_SESSION['userid'];

if($_SERVER["REQUEST_METHOD"] == "GET") {
$active=$_SESSION['userid'];
    $postid=$_GET['sendPost'];
    $message=$_GET['sendComment'];
	$sqlI = "INSERT INTO comments(postid,messages,userid) VALUES ('$postid','$message','$active')";
    $resultI = mysqli_query($conn,$sqlI);
    $sqlN ="SELECT * FROM comments WHERE postid=$postid AND userid=$active;";
    $resultN = mysqli_query($conn,$sqlN);
    $rowN =mysqli_fetch_assoc($resultN);
    $sendNot= $rowN['commentid'];
    $sqlFP="SELECT * FROM posts WHERE postid=$postid";
    $resultFP = mysqli_query($conn,$sqlFP);
    $rowFP =mysqli_fetch_assoc($resultFP);
    $secondaryU=$rowFP['userid'];
    $sqlNI ="INSERT INTO notif(userid,seconduser,postid,notType,seen,pinpoint) 
    VALUES('$secondaryU','$active','$postid',2,0,'$sendNot');";
    $resultNI = mysqli_query($conn,$sqlNI);
}else{
    $active=$_SESSION['userid'];
    $postid=$_POST['postValue'];
}

?>


<head>
  <meta charset="utf-8">
  <title>Home</title>
  <?php
include('headerInclude.php');


?>
  </head>
<body id='chn'> 

<div id='left'>

<div id="navi">


<ul>
<li>
<i class='fab fa-twitter' id="twit"></i>
</li>
<li>
<a href="main.php"><i class='fas fa-home' id="firstLi"></i>
Home</a>

</li>


<li>
<a href="noti.php"><i class='fas fa-bell' id="secondLi"></i>
Notifications</a>
</li>
<li>
<a href="messages.php"><i class='fas fa-inbox' id="thirdLi"></i>
Messages</a>
</li>

<li>
<i class='far fa-bookmark' id="bookLi"></i>
Bookmarks
</li>
<li>

<?php 

echo "<a href='othersPage.php?profVal=".$active."'>";

?><i class='fas fa-thumbtack' id="fourthLi"></i>



Profile</a>

</li>



<li>
<i class='far fa-list-alt' id="moreLi"></i>

More
</li>




<li id="bottomMe">
<a href="logOut.php">Log Out</a>
</li>
</ul>


</div>
</div>
<div id='middleC'>


<?php


$sqlL ="SELECT * FROM posts WHERE postid = $postid;";
$resultL = mysqli_query($conn,$sqlL);
$rowL=mysqli_fetch_assoc($resultL);

$s=$rowL['userid'];
$nq="SELECT * FROM users WHERE userid=$s;";
$rq=mysqli_query($conn,$nq);
$rn=mysqli_fetch_assoc($rq);

$sqlLC ="SELECT * FROM comments WHERE postid = $postid;";
$resultLC = mysqli_query($conn,$sqlLC);

$findComments ="SELECT * FROM comments WHERE postid=$postid;";
$resultComments = mysqli_query($conn,$findComments);
$countC=mysqli_num_rows($resultComments);


echo '<img src="headshotty.png" class="smallH"><h6 class="boldName">'.ucwords(strtolower($rn['firstName'])." ".strtolower($rn['lastName'])).'</h6>';
echo '<div id="singlePost">';
echo "<h6 id='cmtView'>".$rowL['msg']."</h6><br>";
echo "<button type='button' class='comBtn' value=".$rowL['postid']." onclick='comment(this.value)'><i class='fab fa-rocketchat' id='comit'></i></button><span style='color:#8898A6'>".$countC."</span>";
echo "<button type='button' class='rt'><i class='fas fa-retweet' id='rtBtn'>&nbsp;".rand(10,100)."</i>
</button>";
echo "<button type='button' class='thumbs' value=".$rowL['postid']." onclick='likeIt()'><i class='far fa-heart' id='likeit'></i></button><span style='color:#8898A6'>".$rowL['likes']."</span>";

echo "<hr class='notihr'>";
echo '</div>';

$sqlL ="SELECT * FROM posts WHERE postid = $postid;";
$resultL = mysqli_query($conn,$sqlL);
$rowLL=mysqli_fetch_assoc($resultL);

$sqlLC ="SELECT * FROM comments WHERE postid = $postid;";
$resultLC = mysqli_query($conn,$sqlLC);


  if(mysqli_num_rows($resultLC)>0){
    while($rowLC=mysqli_fetch_assoc($resultLC)){
        $userIDD = $rowLC['userid'];
        $sqlLN ="SELECT * FROM users WHERE userid = $userIDD";
$resultLN = mysqli_query($conn,$sqlLN);
$rowLN=mysqli_fetch_assoc($resultLN);

if(isset($message)){
if($rowLC['messages']==$message){
  echo '<img class="smallH" src="headshotty.png"><h6 class="boldName" style="padding-left:.5em;background-color: background-color: #39424D;">'.ucwords(strtolower($rowLN['firstName']." ".$rowLN['lastName'])).'</h6><br>';

        echo "<p style='padding-left:4.5em;'>".$rowLC['messages']."</p>";
}else{
  echo '<img class="smallH" src="headshotty.png"><h6 class="boldName" style="padding-left:.5em;background-color: background-color: #39424D;">'.ucwords(strtolower($rowLN['firstName']." ".$rowLN['lastName'])).'</h6><br>';

  echo "<p style='padding-left:4.5em;'>".$rowLC['messages']."</p>";
}
  }else{
    echo '<img class="smallH" src="headshotty.png"><h6 class="boldName" style="padding-left:.5em;background-color: background-color: #39424D;">'.ucwords(strtolower($rowLN['firstName']." ".$rowLN['lastName'])).'</h6><br>';
    echo "<p style='padding-left:4.5em;'>".$rowLC['messages']."</p>";

  }

  
  echo "<hr class='notihr'>";

}
  }

?>

</div>

<?php
include('rightInc.php');


?>

<script src='script.js'>



</script>


</body>

</html>

