<?php
include('mainInclude.php');

?>

<head>
  <meta charset="utf-8">
  <title>Home</title>
  <?php
include('headerInclude.php');


?>
  </head>
<body>

<?php
include('leftInc.php');

$val = $_GET['profVal'];

$sqlName ="SELECT * FROM users WHERE userid= $val";
$resultName = mysqli_query($conn,$sqlName);
$name = mysqli_fetch_assoc($resultName);

?>

<div id='middleC'>
<h5 id="midHome"><?php
echo ucwords(strtolower($name['firstName']." ".$name['lastName']));

?></h5>


<hr class='notihr'>

<div style='position:relative;top:-20px;left:-20px;height:360px;width:820px;border-bottom:1px solid #37454D;'>
<div id='backSplash' style='height:200px;width:820px;background-color:#3D5465;'>


<img style="position:relative; top:120px;left:1em;border:4px solid #15212B; border-radius:100%;height:140px;width:140px;" src='headshotty.png'>
<h5 style="position:relative;top:122px; left:22px; font-weight:bold;">

<?php


echo ucwords(strtolower($name['firstName']." ".$name['lastName']));

$sqlFollowing ="SELECT * FROM userFollows WHERE userid = $val AND whotheyfollow != $val";
$resultFollowing = mysqli_query($conn,$sqlFollowing);
$following = mysqli_num_rows($resultFollowing);

$sqlFollow ="SELECT * FROM userFollows WHERE whotheyfollow = $val";
$resultFollow = mysqli_query($conn,$sqlFollow);
$follow = mysqli_num_rows($resultFollow);

?>
</h5>

<p style="position:relative;top:120px; left:21px;">
<span style='font-weight:bold; color:#FFFFFF;'>
<?php
echo $following;

?>
</span>
<span style="color:#8898A6">
Following
</span>
&nbsp;&nbsp;
<span style='font-weight:bold; color:#FFFFFF;'>
<?php
echo $follow;

?>

</span>
<span style="color:#8898A6">
Followers
</span>



</p>
<?php


echo "<div id='space'>";

$sqlL ="SELECT * FROM userFollows WHERE whotheyfollow = $val AND 
userid = $active;";
$resultL = mysqli_query($conn,$sqlL);
$count = mysqli_num_rows($resultL);

if($val!=$active){
if($count ===1){
  echo "<button id='followBtn' value=".$val." style='background-color:#1EA2F1;color:#FFFFFF;font-weight:bold;' onclick='follow(this.value)'>Following</button>";
}else{
  echo "<button id='followBtn' value=".$val." style='width:80px; height:40px; border-radius:20px; font-weight:bold; background-color: rgb(21,33,43);border:1px solid rgb(30,162,241);color:rgb(30,162,241);' onclick='follow(this.value)'>Follow</button>";
}

}else{
  echo "<button id='followBtn' style='right:-480px;width:inherit; padding-left:1em;padding-right:1em; height:40px; border-radius:20px; font-weight:bold; background-color: rgb(21,33,43);border:1px solid rgb(30,162,241);color:rgb(30,162,241);''>Edit profile</button>";

}
echo "</div>";


?>
</div>





</div>
<br>
<br>
<br>
<?php






$sql = "SELECT * FROM posts WHERE userid = '$val'";
  $result = mysqli_query($conn,$sql);
  $c = mysqli_num_rows($result);
  

  if($c<1){
    echo "<h1 style='position:relative;left:1em;'>".ucwords(strtolower($name['firstName']." ".$name['lastName']))." hasn't posted yet</h1>";

  }else{
    if(mysqli_num_rows($result)>0){
        while($row=mysqli_fetch_assoc($result)){

          $formId = "postValue".$row['postid'];
$profVal=$row['userid'];
$findName = "SELECT * FROM users WHERE userid=$profVal;";
$resultName = mysqli_query($conn,$findName);
$personRow=mysqli_fetch_assoc($resultName);
$atname=strtolower($personRow['firstName'])."".strtolower($personRow['lastName']);
$postName =ucwords(strtolower($personRow['firstName'])." ".strtolower($personRow['lastName']));
$postidd=$row['postid'];
$findComments ="SELECT * FROM comments WHERE postid=$postidd;";
$resultComments = mysqli_query($conn,$findComments);
$countC=mysqli_num_rows($resultComments);
          
            $timee=explode("-", $row['timey']);

            $newA= str_split($timee[2],2);
            $timee[2]=$newA[0];
            
            
           for($a=0; $a< count($timee); $a++){
            //echo "<p style='margin-left:300px;'>".$timee[$a]."</p>";
            }
            echo "<div style='position:relative; height:inherit;margin-top:-60px;'>";
            echo "<p style='positon:relative;left:-500px;' class='message'><img class='smallH' style='margin-right:1em;' src='headshotty.png'><span style='font-weight:bold;position:relative;top:-16px;'>".$postName."</span><div style='width:500px; color:#FFFFFF; position:relative;top:-50px; left:75px;'>".$row['msg']."</div></p><br>";
            echo '<div style="position:relative; top:-70px;">';
            echo "<button class='comBtn' value=".$row['postid']." onclick='comment(this.value)'><i class='fab fa-rocketchat' id='comit'></i></button><span style='color:#8898A6'>".$countC."</span>";
            echo "<button class='rt'><i class='fas fa-retweet' id='rtBtn'>&nbsp;".rand(10,100)."</i>
            </button>";
            echo "<button class='thumbs' value=".$row['postid']." onclick='likeIt(this.value,".$row['likes'].",".$profVal.")'><i class='far fa-heart' id='likeit'></i></button><span style='color:#8898A6'>".$row['likes']."</span>";
            echo '</div>';
            echo "<hr class='notihr' style='top:-80px;'>";
            echo "</div>";
      }
      }
    }




?>

</div>

<div id='coverPage'>
<form method='POST' enctype='multipart/form-data' action='upload.php'>
<input type='file' name='file'>
<input type='hidden' value=<?php $val;?> name='profile'>
<input type=submit value='submit'>
  </form>

  </div>

<?php
include('rightInc.php');


?>
<script>
function follow(a){
  $('#space').load('loadStatus.php',{
  following: a
    })

}



</script>

</body>

</html>