<?php

include('dbh.php');
session_start();

$active=$_SESSION['userid'];
$posty = $_POST['postId'];


$sqlL ="SELECT * FROM posts WHERE postid = $posty;";
$resultL = mysqli_query($conn,$sqlL);
$rowL=mysqli_fetch_assoc($resultL);
$second=$rowL['userid'];
$findName="SELECT * FROM users WHERE userid=$second;";
$resultN = mysqli_query($conn,$findName);
$rowN=mysqli_fetch_assoc($resultN);
echo '<img class="smallH" src="headshotty.png"><p class="boldName">'.ucwords(strtolower($rowN['firstName'])." ".strtolower($rowN['lastName'])).'</p>';
echo "<p class='message'>".$rowL['msg']."</p><br>";
?>