<?php

include('dbh.php');
session_start();

$active=$_SESSION['userid'];
$posty = $_POST['postId'];


$sqlL ="SELECT * FROM posts WHERE postid = $posty;";
$resultL = mysqli_query($conn,$sqlL);
$rowL=mysqli_fetch_assoc($resultL);

echo '<img class="smallH" src="headshotty.png"><h6 class="boldName">EDIT NAME</h6>';
echo "<p class='message'>".$rowL['msg']."</p><br>";
?>