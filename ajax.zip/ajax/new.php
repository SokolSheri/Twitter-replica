<html>
<?php
include('dbh.php');

?>


<head>
  <meta charset="utf-8">
  <title></title>
  <meta name="author" content="">
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link href="css/style.css" rel="stylesheet">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
<div>
<?php
$sql ="SELECT * FROM likes INNER JOIN Post ON post.postid = likes.postid WHERE likes.userid=2";
$result = mysqli_query($conn,$sql);

if(mysqli_num_rows($result)>0){
  while($row=mysqli_fetch_assoc($result)){
  echo 'hi';
}
}

?>

</div>
</body>

</html>