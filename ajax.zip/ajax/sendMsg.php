<html>
<?php
include('dbh.php');
session_start();

$active=$_SESSION['userid'];
$secondary = $_POST['userMsg'];
$msg= $_POST['contents'];

$sql = "INSERT INTO msg(userid,usermsgid,msgC) VALUES ('$active','$secondary','$msg')";
$result = mysqli_query($conn,$sql);

$sqlL ="SELECT * FROM msg WHERE userid = $active AND usermsgid =$secondary OR userid = $secondary AND usermsgid =$active;";
$resultL = mysqli_query($conn,$sqlL);

while($rowL=mysqli_fetch_assoc($resultL)){
    echo "<h5>".$rowL['msgC']."</h5>  <p>".$rowL['clockt']."</p>";
}

echo "<input type='text' id='sendMsg'>";
echo "<button onclick='insertMsg(".$secondary.")'>Send</button>";

?>
