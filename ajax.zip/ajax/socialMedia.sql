-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 25, 2020 at 02:30 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `socialMedia`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `commentid` int(11) NOT NULL,
  `times` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `postid` int(11) NOT NULL,
  `messages` varchar(140) NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`commentid`, `times`, `postid`, `messages`, `userid`) VALUES
(1, '2020-09-23 21:21:55', 2, 's', 1),
(2, '2020-09-23 21:22:09', 2, 'ixbqw', 1),
(3, '2020-09-23 21:22:23', 3, 'wq', 1),
(4, '2020-09-23 21:23:16', 3, 'judge', 8),
(5, '2020-09-23 21:51:37', 3, 'dwq', 8),
(6, '2020-09-23 21:51:50', 3, 'dwq', 8),
(7, '2020-09-23 21:52:10', 4, 'som', 8),
(8, '2020-09-23 21:52:16', 3, 'soms', 8),
(9, '2020-09-23 21:52:29', 3, 'soms', 8),
(10, '2020-09-23 22:27:58', 3, 'soms', 8),
(11, '2020-09-23 22:28:14', 3, 'soms', 8),
(12, '2020-09-23 22:29:24', 2, 'bitch', 10),
(13, '2020-09-23 22:29:32', 3, 'bitch ass', 10),
(14, '2020-09-23 22:45:08', 1, 'nig', 10),
(15, '2020-09-23 22:45:16', 1, 'nice', 10),
(16, '2020-09-23 22:45:29', 1, 'bs', 10),
(17, '2020-09-23 22:57:15', 1, 'yo', 10),
(18, '2020-09-24 20:48:49', 1, 'new comment', 10),
(19, '2020-09-24 20:49:01', 2, 'new comment again', 10);

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE `likes` (
  `likeid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `postid` int(11) NOT NULL,
  `liked` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `likes`
--

INSERT INTO `likes` (`likeid`, `userid`, `postid`, `liked`) VALUES
(5, 1, 2, 1),
(8, 1, 3, 1),
(9, 1, 4, 0),
(10, 10, 1, 0),
(11, 10, 2, 0),
(12, 10, 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `msg`
--

CREATE TABLE `msg` (
  `messageid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `usermsgid` int(11) NOT NULL,
  `msgC` varchar(200) NOT NULL,
  `clockt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `msg`
--

INSERT INTO `msg` (`messageid`, `userid`, `usermsgid`, `msgC`, `clockt`) VALUES
(1, 1, 11, 'sok hicks', '2020-09-24 21:55:54'),
(2, 1, 8, 'sok judge', '2020-09-24 22:05:16'),
(3, 1, 8, 'sok judge 2', '2020-09-24 23:24:37'),
(4, 1, 11, 'sok hicks 2', '2020-09-24 23:31:41'),
(17, 1, 8, 'my son', '2020-09-25 00:26:35'),
(18, 1, 11, 'i love you', '2020-09-25 00:26:41'),
(19, 1, 8, 'yo', '2020-09-25 00:30:04');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `postid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `message` varchar(140) NOT NULL,
  `likes` int(11) NOT NULL,
  `timey` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`postid`, `userid`, `message`, `likes`, `timey`) VALUES
(1, 1, 'dont include', 0, '2020-09-02 21:49:05'),
(2, 11, 'POST ID 2', 200, '2020-09-02 21:49:05'),
(3, 11, 'POST ID 3', 12, '2020-09-02 21:49:05'),
(4, 11, 'POST ID 4', 100, '2020-09-02 21:49:39');

-- --------------------------------------------------------

--
-- Table structure for table `userFollows`
--

CREATE TABLE `userFollows` (
  `followid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `whotheyfollow` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `userFollows`
--

INSERT INTO `userFollows` (`followid`, `userid`, `whotheyfollow`) VALUES
(19, 1, 11),
(21, 8, 11),
(22, 10, 1),
(23, 10, 11),
(24, 1, 8),
(25, 11, 1),
(26, 8, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userid` int(11) NOT NULL,
  `firstName` varchar(100) NOT NULL,
  `lastName` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `pass` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `firstName`, `lastName`, `email`, `pass`) VALUES
(1, 'SOKOL', 'SHERI', 'sokolsheri@gmail.com', '1234'),
(8, 'AARON', 'JUDGE', 'ajudge@yankees.com', '1234'),
(9, 'REY', 'SHERI', 'r@aol.com', '1'),
(10, 'NIGEL', 'HAYES', 'n@aol.com', '1'),
(11, 'AARON', 'HICKS', 'ahicks@yankees.com', '1234');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`commentid`);

--
-- Indexes for table `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`likeid`),
  ADD KEY `LikeID` (`likeid`);

--
-- Indexes for table `msg`
--
ALTER TABLE `msg`
  ADD PRIMARY KEY (`messageid`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`postid`),
  ADD UNIQUE KEY `PostID` (`postid`),
  ADD KEY `PostID_2` (`postid`);

--
-- Indexes for table `userFollows`
--
ALTER TABLE `userFollows`
  ADD PRIMARY KEY (`followid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `commentid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `likes`
--
ALTER TABLE `likes`
  MODIFY `likeid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `msg`
--
ALTER TABLE `msg`
  MODIFY `messageid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `postid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `userFollows`
--
ALTER TABLE `userFollows`
  MODIFY `followid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
