<?php

include('dbh.php');
session_start();


?>

<head>
  <meta charset="utf-8">
  <title>Home</title>
  <meta name="author" content="">
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link href="css/style.css" rel="stylesheet">

  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">


  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


  <style>



  </style>

  </head>
<body>

<?php


$val = $_GET['profVal'];
$active= $_SESSION['userid'];

echo "<div id='space'>";

$sqlL ="SELECT * FROM userFollows WHERE whotheyfollow = $val AND 
userid = $active;";
$resultL = mysqli_query($conn,$sqlL);
$count = mysqli_num_rows($resultL);

if($count ===1){
  echo "<button id='followBtn' value=".$val." style='color:red;' onclick='follow(this.value)'>Follow</button>";
}else{
  echo "<button id='followBtn' value=".$val." style='color:blue;' onclick='follow(this.value)'>Follow</button>";
}

echo "</div>";
$sql = "SELECT * FROM posts WHERE userid = '$val'";
	$result = mysqli_query($conn,$sql);
    if(mysqli_num_rows($result)>0){
        while($row=mysqli_fetch_assoc($result)){
            echo "<p class='message'>".$row['message']."</p><br>";
      }
      }




?>

<script>
function follow(a){
  $('#space').load('loadStatus.php',{
  following: a
    })

}


</script>

</body>

</html>