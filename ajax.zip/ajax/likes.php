<?php

include('dbh.php');
session_start();

$active=$_SESSION['userid'];
$posty = $_POST['postId'];
$likeNum = $_POST['likes'];
$secondaryL =$_POST['second'];

$sqlL ="SELECT * FROM likes WHERE postid = $posty AND 
userid = $active;";
$resultL = mysqli_query($conn,$sqlL);
$count = mysqli_num_rows($resultL);
$rowL=mysqli_fetch_assoc($resultL);

if($count!==1){
    $sqlI ="INSERT INTO likes(userid,postid,liked) VALUES('$active','$posty',1);";
    $resultI = mysqli_query($conn,$sqlI);
    
    $sqlN ="SELECT * FROM likes WHERE postid=$posty AND userid=$active;";
    $resultN = mysqli_query($conn,$sqlN);
    $rowN =mysqli_fetch_assoc($resultN);
    $sendNot= $rowN['likeid'];
    $sqlNI ="INSERT INTO notif(userid,seconduser,postid,notType,seen,pinpoint) 
    VALUES('$secondaryL','$active','$posty',1,0,'$sendNot');";
    $resultNI = mysqli_query($conn,$sqlNI);
    $likeNum = $likeNum +1;
    $sqlUP ="UPDATE posts SET likes=$likeNum WHERE postid=$posty;";
    $resultUP = mysqli_query($conn,$sqlUP);
    
}else{
  
    $sqlN ="SELECT * FROM likes WHERE postid=$posty AND userid=$active;";
    $resultN = mysqli_query($conn,$sqlN);
    $rowN =mysqli_fetch_assoc($resultN);
    $sendNot= $rowN['likeid'];
  
    if($rowL['liked']==0){
    $sqlU ="UPDATE likes SET liked=1 WHERE userid=$active AND postid=$posty;";
    $resultU = mysqli_query($conn,$sqlU); 
    $sqlNI ="INSERT INTO notif(userid,seconduser,postid,notType,seen,pinpoint) 
    VALUES('$secondaryL','$active','$posty',1,0,$sendNot);";
    $resultNI = mysqli_query($conn,$sqlNI);
    
    $likeNum = $likeNum +1;
    $sqlUP ="UPDATE posts SET likes=$likeNum WHERE postid=$posty;";
    $resultUP = mysqli_query($conn,$sqlUP);
}else{
    $sqlU ="UPDATE likes SET liked=0 WHERE userid=$active AND postid=$posty;";
    $resultU = mysqli_query($conn,$sqlU); 
    $sqlD = "DELETE FROM notif WHERE pinpoint=$sendNot;";
    $resultD = mysqli_query($conn,$sqlD);
    $likeNum = $likeNum -1;
    $sqlUP ="UPDATE posts SET likes=$likeNum WHERE postid=$posty;";
    $resultUP = mysqli_query($conn,$sqlUP);
}

}

$sql ="SELECT DISTINCT msg,postid,likes,posts.userid FROM posts INNER JOIN userFollows ON posts.userid = userFollows.whotheyfollow WHERE userFollows.userid='$active' OR posts.userid='$active' ORDER BY posts.timey DESC";
$result = mysqli_query($conn,$sql);

if(mysqli_num_rows($result)>0){
  while($row=mysqli_fetch_assoc($result)){
$formId = "postValue".$row['postid'];
$profVal=$row['userid'];
echo "<a href='othersPage.php?profVal=".$profVal."'>";
echo '<img class="smallH" src="headshotty.png"><h6 class="boldName">EDIT NAME</h6>';
echo '</a>';
echo "<div class='postBox'>";
echo "<form action='comment.php' method='post' id=".$formId.">";
echo "<div onclick='viewPost(".$row['postid'].")'>";
echo "<input type='hidden' name='postValue' id='postValue' value=".$row['postid'].">";
  echo "<p class='message' >".$row['msg']."</p><br>";
  echo "</div>";
  echo "</form>";
  echo "<button class='thumbs' value=".$row['postid']." onclick='likeIt(this.value,".$row['likes'].",".$profVal.")'>&#128077;</button>".$row['likes']."<button value=".$row['postid']." onclick='comment(this.value)'>Comment</button> ";
  echo "</div><br>";
}
}





?>