<?php

include('dbh.php');
session_start();

$active=$_SESSION['userid'];
$posty = $_POST['postId'];
$likeNum = $_POST['likes'];

$sqlL ="SELECT * FROM likes WHERE postid = $posty AND 
userid = $active;";
$resultL = mysqli_query($conn,$sqlL);
$count = mysqli_num_rows($resultL);
$rowL=mysqli_fetch_assoc($resultL);

if($count!==1){
    $sqlI ="INSERT INTO likes(userid,postid,liked) VALUES('$active','$posty',1);";
    $resultI = mysqli_query($conn,$sqlI);
    $likeNum = $likeNum +1;
    $sqlUP ="UPDATE posts SET likes=$likeNum WHERE postid=$posty;";
    $resultUP = mysqli_query($conn,$sqlUP);
    
}else if($rowL['liked']==0){
    $sqlU ="UPDATE likes SET liked=1 WHERE userid=$active AND postid=$posty;";
    $resultU = mysqli_query($conn,$sqlU); 
    $likeNum = $likeNum +1;
    $sqlUP ="UPDATE posts SET likes=$likeNum WHERE postid=$posty;";
    $resultUP = mysqli_query($conn,$sqlUP);
}else{
    $sqlU ="UPDATE likes SET liked=0 WHERE userid=$active AND postid=$posty;";
    $resultU = mysqli_query($conn,$sqlU); 
    $likeNum = $likeNum -1;
    $sqlUP ="UPDATE posts SET likes=$likeNum WHERE postid=$posty;";
    $resultUP = mysqli_query($conn,$sqlUP);
}


$sql ="SELECT * FROM posts INNER JOIN userFollows ON posts.userid = userFollows.whotheyfollow WHERE userFollows.userid='$active'";
$result = mysqli_query($conn,$sql);


if(mysqli_num_rows($result)>0){
  while($row=mysqli_fetch_assoc($result)){
$formId = "postValue".$row['postid'];
echo '<img class="smallH" src="headshotty.png"><h6 class="boldName">EDIT NAME</h6>';
echo "<div class='postBox'>";
echo "<form action='comment.php' method='post' id=".$formId.">";
echo "<div onclick='viewPost(".$row['postid'].")'>";
echo "<input type='hidden' name='postValue' id='postValue' value=".$row['postid'].">";
  echo "<p class='message' >".$row['message']."</p><br>";
  echo "</div>";
  echo "</form>";
  echo "<button class='thumbs' value=".$row['postid']." onclick='likeIt(this.value,".$row['likes'].")'>&#128077;</button>".$row['likes']."<button value=".$row['postid']." onclick='comment(this.value)'>Comment</button> ";
  
  echo "</div><br>";


}
}





?>