<html>

<?php
include('dbh.php');

?>

<head>
  <meta charset="utf-8">
  <title></title>
  <meta name="author" content="">
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link href="css/style.css" rel="stylesheet">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

  <style>
 

  .thumbs{
    background-color: transparent;
    border:none;
    outline:none;
    height:inherit;
    font-size: 20px;
    opacity:.5;
    
  }
  
  .thumbs:hover{
    cursor:pointer;
    border-radius: 20px;
    background-color: gold;

  }


  </style>

</head>

<body>

  <div id="placeHere">
  <?php
include 'dbh.php';
$sql ="SELECT * FROM test";
$result = mysqli_query($conn,$sql);

if(mysqli_num_rows($result)>0){
  while($row=mysqli_fetch_assoc($result)){
    $t= 'a'.$row['id'];
    $s='a'.$t;
    $c=1;
    echo "<p>";
    if($row['id']==1){
    echo "<button class='thumbs' id=".$t." value=".$row['value']." style='opacity:1' onclick='funky(".$t.")'>&#128077;</button> ".$row['value'];
    }else{ 
    echo "<button class='thumbs' id=".$t." value=".$row['value']." style='opacity:.5' onclick='funky(".$t.")'>&#128077;</button> ".$row['value'];
    }
    echo "<input id=".$s." type='hidden' value=".$c.">";
    echo "</p>";
  }
}

?>
  </div>

  <script src="js/script.js"></script>

  <script>

function funky(a){
  var mainId= $(a).attr('id');
  var id2="a"+mainId;
  
  
  var ogId= parseInt(mainId.replace(/\D/g,''));

  if($('#'+id2).val()==1){
    var vally = parseInt($(a).val())+1;
  var change= $('#'+id2).val(2);
  $('#placeHere').load('loadVals.php',{
  newVally: vally,
  changed: change.val(),
  main: ogId
    })
}else{
  var vally = parseInt($(a).val())-1;
  var change = $('#'+id2).val(1);
  
  $('#placeHere').load('loadVals.php',{
  newVally: vally,
  changed: change.val(),
  main: ogId
    })  
}
}

</script>
</body>

</html>