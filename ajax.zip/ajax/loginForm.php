<!DOCTYPE html>

<?php
session_start();
?>
<html>

<head>
  <meta charset="utf-8">
  <title>Login</title>
  <meta name="author" content="">
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link href="css/style.css" rel="stylesheet">

  <style>
  #loginForm,#createAcc{
      position: absolute;
      border: 1px solid black;
      top:20%;
      height: inherit;
      width: inherit;
      text-align: center;
      padding: 0 1em;
      border-radius: 4px;
  }

  #loginForm{
    right: 20%;
    
  }
 
  #createAcc{
    position: absolute;
            top:45%;
            margin-top: -180px;
            margin-left: 50%;
            left:-180px;
           
  }

  #email,#password,#log{
      padding-left:1em;
      font-size:16px;
      height:50px;
      margin-bottom: 1.5em;
      width:286px;
      border:1px solid lightgray;
      border-radius: 6px;
  }

  #img1{
    font-size:16px;
      height:25px;
      border-radius: 6px;
  }

  #firstName,#lastName{
    padding-left:1em;
    font-size:16px;
      height:50px;
      margin-bottom: 1.5em;
      width:132px;
      border:1px solid lightgray;
      border-radius: 6px;
  }
  
  #log,#notMember{
    width:306px; 
  }

  hr{
      width:98%;
  }

 #log:hover,#notMember:hover,#img1:hover{
cursor:pointer;
 }

#formDiv{
    height:717px;
    background-color:white;
    opacity: .8;
    width:100%;
    margin:0;
    visibility:hidden;
    
}

#labelFor{
  font-size:20px;
  font-weight:bold;
}



  </style>
</head>

<body>

<form id="loginForm" action="login.php" method="post">
<br>
 <input type="text" id="email" name="emailLogin" placeholder="&nbsp;&nbsp;&nbsp;Email"><br>
    <input type="password" id="password" name="passLogin" placeholder="&nbsp;&nbsp;&nbsp;Password"><br>
    <button type="submit" value="submit" id="log">LOG IN</button><br><hr><br>
    <button type="notMember" value="create" id="log">Create New Account</button>
       
    </form>

    <div id="formDiv">
    
    
    </div>

    <form id="createAcc" action="createAcc.php" method="post">
    <h2>Sign Up</h2>
<hr>
<input type="text" id="firstName" name="firstName" placeholder="&nbsp;&nbsp;&nbsp;First Name"> <input type="text" id="lastName" name="lastName" placeholder="&nbsp;&nbsp;&nbsp;Last Name"><br>
 <input type="text" id="email" name="emailCreate" placeholder="&nbsp;&nbsp;&nbsp;Email"><br>
    <input type="password" id="password" name="passCreate" placeholder="&nbsp;&nbsp;&nbsp;Password"><br>
   <!--<label for="img1"><span id="labelFor">Select image:</span></label><br><br><br>
  <input type="file" id="img1" name="img1" accept="image/*">
  <br><br><br> -->
    <button type="submit" value="submit" id="log">Create Account</button><br><br>
    
       
    </form>

  
  <script src="js/script.js"></script>
</body>

<div>


</div>

</html>