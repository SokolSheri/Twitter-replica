<html>
<?php
include('dbh.php');
session_start();

$active=$_SESSION['userid'];
/*if($_SESSION['email'] === NULL){
  header("location: logOut.php");
}
*/

?>


<head>
  <meta charset="utf-8">
  <title>Home</title>
  <meta name="author" content="">
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link href="css/style.css" rel="stylesheet">

  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">


  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

  
  <style>

  #left,#right{
position:fixed;
top:0;
height:100%;
  }
  #left{ 
    width:25%;
    left:0;
    border-right:1px solid black;
  }
  #middle,#middle2{
    position:absolute;
    width:40%;
    left:25%;
    overflow: scroll; 
  }

  #middle2{
    position:absolute;
    height:200px;
    top:5%;
    border-bottom:1px solid black;
  }

  #middle{
    top:35%;  
  }

  #right{
    width:35%;
    left:65%;
    border-left:1px solid black;
  }

  .postBox{
    border-bottom:1px solid black;
    height: inherit;
    padding: 1em;
  }

  .smallH{
    position:relative;
    height: 50px;
    width: 50px;
    border-radius: 100%;
    margin-bottom: 10px;
    display:inline-block;
  }
  .message{
    font-size:12px;
     
  }
  .boldName{
    position:relative;
    top:0;
    right: 0;
    color:blue;
    display:inline-block;
    margin-left:10px;
  }

  .thumbs{
    background-color: transparent;
    border:none;
    outline:none;
    height:inherit;
    font-size: 20px;
    opacity:.5;
    outline:none;
  }
  
  .thumbs:hover{
    cursor:pointer;
    border-radius: 20px;
    background-color: gold;

  }

  .thumbs:visited{
    border:none;
    outline:none;
  }

  #makeComment{
    visibility:hidden;
    position:absolute;
    top:0;
    background-color:beige;
    width:100%;
    z-index:100;
    height:100%;
  }

  </style>
</head>
<body>

<div id="left">

<?php

echo '<h1>'.$_SESSION['name'].'</h1>';

?>

<h1>HI</h1>
<a href="noti.php">Notifications</a>



<a href="logOut.php">Log Out</a>
  </div>

  <div id="makeComment">

<div id="putPostHere"></div>

<form id="sendCommentForm" action="comment.php" method="get">
<textarea name="sendComment" id="sendComment"></textarea>
<input type="hidden" value="" id="sendPost" name="sendPost">
<button>Submit</button>
</form>

</div>


<div id="middle2" >

<form id="sendTweet" method="post" action="postTweet.php">
<textarea name="thePost"style="height:160px; width:94.5%; margin-left:1em;margin-right:1em;padding-left:1em;padding-top:1em;"></textarea>
<input type="submit" value="Post">
</form>
</div>
  <div id="middle">

  

  
 
  <?php

  
$sql ="SELECT DISTINCT msg,postid,likes,posts.userid FROM posts INNER JOIN userFollows ON posts.userid = userFollows.whotheyfollow WHERE userFollows.userid='$active' OR posts.userid='$active' ORDER BY posts.timey DESC";
//$sql ="SELECT * FROM posts INNER JOIN userFollows ON posts.userid = userFollows.whotheyfollow WHERE userFollows.userid='$active' OR posts.userid='$active' ORDER BY timey DESC";
$result = mysqli_query($conn,$sql);

if(mysqli_num_rows($result)>0){
  while($row=mysqli_fetch_assoc($result)){
$formId = "postValue".$row['postid'];
$profVal=$row['userid'];
echo "<a href='othersPage.php?profVal=".$profVal."'>";
echo '<img class="smallH" src="headshotty.png"><h6 class="boldName">EDIT NAME</h6>';
echo '</a>';
echo "<div class='postBox'>";
echo "<form action='comment.php' method='post' id=".$formId.">";
echo "<div onclick='viewPost(".$row['postid'].")'>";
echo "<input type='hidden' name='postValue' id='postValue' value=".$row['postid'].">";
  echo "<p class='message' >".$row['msg']."</p><br>";
  echo "</div>";
  echo "</form>";
  echo "<button class='thumbs' value=".$row['postid']." onclick='likeIt(this.value,".$row['likes'].",".$profVal.")'>&#128077;</button>".$row['likes']."<button value=".$row['postid']." onclick='comment(this.value)'>Comment</button> ";
  echo "</div><br>";
}
}

?>

  </div>

  <div id="right">




<form id="searchForm" name="searchForm" action="results.php" method="get">

<input type="text" id="searchBar" name="searchBar" placeholder="Search Friends">


</form>

<div id="showMsgHere">


<h1>MESSAGE</h1>

</div>

<?php

$sqlL = "SELECT usermsgid,userid FROM msg WHERE userid=$active OR usermsgid=$active ORDER BY clockt DESC;";
$resultL = mysqli_query($conn,$sqlL);

$count = mysqli_num_rows($resultL);

if($count>0){

if(mysqli_num_rows($resultL)>0){
  $usersArr = array();
  while($rowL=mysqli_fetch_assoc($resultL)){
    if($rowL['usermsgid']==$active){
      $usermsg =$rowL['userid'];
    }else{
      $usermsg =$rowL['usermsgid'];
    }
    array_push($usersArr,$usermsg);
   
  }

 $usersArr=array_unique($usersArr);
 $usersArr=array_values($usersArr);
 
}


for($x = 0; $x < count($usersArr); $x++){
$userL =$usersArr[$x];

  $sqlLU = "SELECT * FROM users WHERE userid=$userL;";
    $resultLU = mysqli_query($conn,$sqlLU);
    $checkSeen ="SELECT * FROM msg WHERE userid=$userL AND usermsgid=$active AND seen=0";
    $sresult=mysqli_query($conn,$checkSeen);
    $counts = mysqli_num_rows($sresult);
    $rowSeen=mysqli_fetch_assoc($sresult);
    $rowLU =mysqli_fetch_assoc($resultLU);
    $newId="show".$userL;
    $newId2="hide".$userL;
    $sendMsg="sendMsg".$userL;

    if($counts>0){
      echo "<h4 style='color:red;'id=".$newId2." onclick='viewConvo(".$userL.")'>".$rowLU['firstName']." ".$rowLU['lastName']."</h4><br>";

    }else{
    echo "<h4 style='color:blue;' id=".$newId2." onclick='viewConvo(".$userL.")'>".$rowLU['firstName']." ".$rowLU['lastName']."</h4><br>";
    }
    echo "<div id=".$newId." style='visibility:hidden; position:absolute; bottom:0;'>";
    echo "<input type='text' id=".$sendMsg.">";
    echo "<button onclick='insertMsg(".$userL.")'>Send</button>";
    echo "</div>";

    
    
}


}


?>
  </div>

<script>

//resett();
function likeIt(a,b,c){
  
  $('#middle').load('likes.php',{
  postId: a,
  likes: b,
  second:c
    })

}


function resett(){
  setInterval(function(){
   $('#middle').load('/path/to/server/source');
}, 5000)

}

function comment(a){
  document.getElementById('makeComment').style.visibility='visible';
  document.getElementById('sendPost').value = a;
  $('#putPostHere').load('loadPostComment.php',{
  postId: a
    })
}

function viewPost(a){
 document.getElementById('postValue'+a.toString()).submit();
}




function viewConvo(a){

document.getElementById("show"+a).style.visibility = 'visible';
$('h4').hide();



setInterval(function(){ 
  $('#showMsgHere').load('loadMessages.php',{
  userMsg: a
    })
  ; }
, 1000)

}


function insertMsg(a){

  var input= document.getElementById("sendMsg"+a).value;
  
 $('#showMsgHere').load('sendMsg.php',{
  userMsg: a,
  contents : input
    })
    
}



function logThis(a){
  alert(typeof(a));
}

function goBack(){
 location.reload();
}



</script>
</body>

</html>