<html>
<?php
include('mainInclude.php');

?>

<head>
  <title>Home</title>
  <meta charset="utf-8">
 
 <?php
include('headerInclude.php');


?>

</head>
<body>

<div id="left">


<div id="navi">


<ul>
<li>
<i class='fab fa-twitter' id="twit"></i>
</li>
<li>
<a href="main.php"><i class='fas fa-home' id="firstLi"></i>
Home</a>

</li>


<li>
<a href="noti.php"><i class='fas fa-bell' id="secondLi"></i>
Notifications</a>
</li>
<li>
<a href="messages.php"><i class='fas fa-inbox' id="thirdLi"></i>
Messages</a>
</li>

<li>
<i class='far fa-bookmark' id="bookLi"></i>
Bookmarks
</li>
<li>

<?php 

echo "<a href='othersPage.php?profVal=".$active."'>";

?><i class='fas fa-thumbtack' id="fourthLi"></i>



Profile</a>

</li>



<li>
<i class='far fa-list-alt' id="moreLi"></i>

More
</li>

<li>


<button id="sidePost">Tweet</button>


</li>



<li id="bottomMe">
<a href="logOut.php">Log Out</a>
</li>
</ul>

</div>



  </div>
<div id="cmtBack">
  <div id="makeComment">

<div id="putPostHere"></div>

<form id="sendCommentForm" action="comment.php" method="get">
<textarea name="sendComment" id="sendComment"></textarea>
<input type="hidden" value="" id="sendPost" name="sendPost">
<button>Reply</button>
</form>

</div>
</div>

<div id="middle3">

<h5 id="midHome">Home</h5>


</div>
<div id="middle2" >
<img class="smallH" id="inlineB"src="headshotty.png">
<form id="sendTweet" method="post" action="postTweet.php">
<textarea name="thePost" id="thePost" placeholder="What's happening?" onclick='showLine()' onkeydown="showColor()" ></textarea>
<hr id="lineUnder">
<input type="submit" value="Post" id="postBtn">

</form>

</div>

  <div id="middle">

  <?php

  
$sql ="SELECT DISTINCT msg,postid,likes,posts.userid FROM posts INNER JOIN userFollows ON posts.userid = userFollows.whotheyfollow WHERE userFollows.userid='$active' OR posts.userid='$active' ORDER BY posts.timey DESC";
//$sql ="SELECT * FROM posts INNER JOIN userFollows ON posts.userid = userFollows.whotheyfollow WHERE userFollows.userid='$active' OR posts.userid='$active' ORDER BY timey DESC";
$result = mysqli_query($conn,$sql);

if(mysqli_num_rows($result)>0){
  while($row=mysqli_fetch_assoc($result)){
$formId = "postValue".$row['postid'];
$profVal=$row['userid'];
$findName = "SELECT * FROM users WHERE userid=$profVal;";
$resultName = mysqli_query($conn,$findName);
$personRow=mysqli_fetch_assoc($resultName);
$atname=strtolower($personRow['firstName'])."".strtolower($personRow['lastName']);
$postName =ucwords(strtolower($personRow['firstName'])." ".strtolower($personRow['lastName']));
$postidd=$row['postid'];
$findComments ="SELECT * FROM comments WHERE postid=$postidd;";
$resultComments = mysqli_query($conn,$findComments);
$countC=mysqli_num_rows($resultComments);



echo "<div id='singlePost'>";
echo "<a id='aPic' href='othersPage.php?profVal=".$profVal."'>";
echo '<img class="smallH" src="headshotty.png"><p class="boldName">'.$postName.'</p>&nbsp;&nbsp; <span class="atName">@'.$atname.' </span>';
echo '</a>';
echo "<div class='postBox'>";
echo "<form action='comment.php' method='post' id=".$formId.">";
echo "<div onclick='viewPost(".$row['postid'].")'>";
echo "<input type='hidden' name='postValue' id='postValue' value=".$row['postid'].">";
  echo "<p class='message' >".$row['msg']."</p><br>";
  echo "</div>";
  echo "</form>";
  echo "<button class='comBtn' value=".$row['postid']." onclick='comment(this.value)'><i class='fab fa-rocketchat' id='comit'></i></button><span style='color:#8898A6'>".$countC."</span>";
  echo "<button class='rt'><i class='fas fa-retweet' id='rtBtn'>&nbsp;".rand(10,100)."</i>
  </button>";
  echo "<button class='thumbs' value=".$row['postid']." onclick='likeIt(this.value,".$row['likes'].",".$profVal.")'><i class='far fa-heart' id='likeit'></i></button><span style='color:#8898A6'>".$row['likes']."</span>";
  

 

  echo "</div><br>";
  echo "</div>";
}
}

?>

  </div>

  <div id="right">




<form id="searchForm" name="searchForm" action="results.php" method="get">



<input type="text" id="searchBar" name="searchBar" placeholder="Search Friends">

</form>

<div id="msgPop">
<span id="hideMsg">Messages  </span>
<i onclick='goBack()' class='material-icons' id='goBArr'>arrow_back</i>
<i class='fas fa-arrow-up' id="upArrow" onclick="popToggle('a')"></i>
<i class='fas fa-arrow-down' id="downArrow" onclick="popToggle('b')"></i>

<div id="showMsgHere">

<hr style='width:92%;background-color:#37454D;position:absolute;left:15px;'><br>

</div>

<?php



$sqlL = "SELECT usermsgid,userid FROM msg WHERE userid=$active OR usermsgid=$active ORDER BY clockt DESC;";
$resultL = mysqli_query($conn,$sqlL);

$count = mysqli_num_rows($resultL);

if($count>0){

if(mysqli_num_rows($resultL)>0){
  $usersArr = array();
  while($rowL=mysqli_fetch_assoc($resultL)){
    if($rowL['usermsgid']==$active){
      $usermsg =$rowL['userid'];
    }else{
      $usermsg =$rowL['usermsgid'];
    }
    array_push($usersArr,$usermsg);
   
  }

 $usersArr=array_unique($usersArr);
 $usersArr=array_values($usersArr);
 
}

echo "<div id='listNames'>";
echo "<br>";
//echo "<hr style='width:92%;background-color:#37454D;position:absolute;left:15px;'><br>";

for($x = 0; $x < count($usersArr); $x++){
$userL =$usersArr[$x];

  $sqlLU = "SELECT * FROM users WHERE userid=$userL;";
    $resultLU = mysqli_query($conn,$sqlLU);
    $checkSeen ="SELECT * FROM msg WHERE userid=$userL AND usermsgid=$active AND seen=0";
    $sresult=mysqli_query($conn,$checkSeen);
    $counts = mysqli_num_rows($sresult);
    $rowSeen=mysqli_fetch_assoc($sresult);
    $rowLU =mysqli_fetch_assoc($resultLU);
    $newId="show".$userL;
    $newId2="hide".$userL;
    $sendMsg="sendMsg".$userL;

   

    if($counts>0){
      echo "<div class='convoNames' style='color:#1EA2F1;'id=".$newId2." onclick='viewConvo(".$userL.")'>".ucwords(strtolower($rowLU['firstName'])." ".strtolower($rowLU['lastName']))."</div>";

    }else{
    echo "<div class='convoNames' id=".$newId2." onclick='viewConvo(".$userL.")'>".ucwords(strtolower($rowLU['firstName'])." ".strtolower($rowLU['lastName']))."</div>";
    }
    echo "<div id=".$newId." style='visibility:hidden; position:absolute; top:1400%;'>";
    echo "<input class='inlineSend' type='text' placeholder='Start a new message' id=".$sendMsg.">";
    echo "<button class='inlineBtn' onclick='insertMsg(".$userL.")'><i id='sPlane' class='material-icons'>send</i>
    </button>";
    echo "</div>";
    

    
    
}

echo "</div>";


}



?>

  </div>

</div>

<script>

//resett();
function likeIt(a,b,c){
  
  $('#middle').load('likes.php',{
  postId: a,
  likes: b,
  second:c
    })

}


function resett(){
  setInterval(function(){
   $('#middle').load('/path/to/server/source');
}, 5000)

}

function comment(a){
  document.getElementById('cmtBack').style.visibility='visible';
  document.getElementById('sendPost').value = a;
  $('#putPostHere').load('loadPostComment.php',{
  postId: a
    })
}

function viewPost(a){
 document.getElementById('postValue'+a.toString()).submit();
}




function viewConvo(a){

document.getElementById('hideMsg').style.visibility="hidden";
document.getElementById("show"+a).style.visibility = 'visible';
document.getElementById('goBArr').style.visibility ='visible';


$('.convoNames').hide();

setInterval(function(){ 
  $('#showMsgHere').load('loadMessages.php',{
  userMsg: a
    })
  ; }
, 1000)

}

function upScroll(){

  var element = document.getElementById("showMsgHere");
    element.scrollTop = element.scrollHeight;
    
}

function insertMsg(a){

  var input= document.getElementById("sendMsg"+a).value;
  
 $('#showMsgHere').load('sendMsg.php',{
  userMsg: a,
  contents : input
    })
    
}



function logThis(a){
  alert(typeof(a));
}

function goBack(){
 location.reload();
}

function popToggle(a){

  if(a=='a'){
    document.getElementById('msgPop').style.height='500px';
 document.getElementById('listNames').style.visibility="visible";
 document.getElementById('upArrow').style.visibility="hidden";
 document.getElementById('downArrow').style.visibility="visible";
 document.getElementById('showMsgHere').style.visibility="visible";

 if(document.getElementById('hideMsg').style.visibility=="visible"){
  document.getElementById('hideMsg').style.visibility="hidden";
  document.getElementById('goBArr').style.visibility="visible";
 }
  }else{
    document.getElementById('downArrow').style.visibility="hidden";
 document.getElementById('msgPop').style.height='60px';
 document.getElementById('upArrow').style.visibility="visible";
 document.getElementById('downArrow').style.visibility="hidden";
 document.getElementById('listNames').style.visibility="hidden";
 document.getElementById('showMsgHere').style.visibility="hidden";
 document.getElementById('goBArr').style.visibility="hidden";
 document.getElementById('hideMsg').style.visibility="visible";
 
  }
 
}

function showLine(){
  document.getElementById('lineUnder').style.visibility="visible";
  document.getElementById('middle2').style.height="170px";
  document.getElementById('middle').style.top="35%";
}

function showColor(){
var lengthy=document.getElementById('thePost').value.length;

if(lengthy>=0){
  document.getElementById('postBtn').style.color="#FFFFFF";
  document.getElementById('postBtn').style.backgroundColor="#1EA2F1";
  document.getElementById('postBtn').style.cursor="pointer";
}

var KeyID = event.keyCode;
   switch(KeyID)
   {
      case 8:
        if(lengthy<=1){
  document.getElementById('postBtn').style.color="#8A8F94";
  document.getElementById('postBtn').style.backgroundColor="#20608E";
  document.getElementById('postBtn').style.cursor="default";
}
   }

  
}


</script>
</body>

</html>