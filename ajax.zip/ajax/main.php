<html>
<?php
include('dbh.php');
session_start();

$active=$_SESSION['userid'];
/*if($_SESSION['email'] === NULL){
  header("location: logOut.php");
}
*/

?>


<head>
  <meta charset="utf-8">
  <title>Home</title>
  <meta name="author" content="">
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link href="css/style.css" rel="stylesheet">

  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">


  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

  
  <style>

  #left,#right{
position:fixed;
top:0;
height:100%;
  }
  #left{
      
      width:25%;
      left:0;
      
      
      border-right:1px solid black;
  }
  #middle{
      position:absolute;
      width:40%;
      top:0;
      left:25%;
      overflow: scroll; 
  }

  #right{
      width:35%;
      left:65%;
      border-left:1px solid black;
  }
  .postBox{
      border-bottom:1px solid black;
      height: inherit;
      padding: 1em;
  }

  .smallH{
      position:relative;
  height: 50px;
      width: 50px;
    border-radius: 100%;
    margin-bottom: 10px;
    display:inline-block;
  }
  .message{
      font-size:12px;
     
  }
  .boldName{
      position:relative;
      top:0;
      right: 0;
      color:blue;
      display:inline-block;
      margin-left:10px;
  }

  .thumbs{
    background-color: transparent;
    border:none;
    outline:none;
    height:inherit;
    font-size: 20px;
    opacity:.5;
    outline:none;
  }
  
  .thumbs:hover{
    cursor:pointer;
    border-radius: 20px;
    background-color: gold;

  }

  .thumbs:visited{
    border:none;
    outline:none;
  }

  #makeComment{
  visibility:hidden;
  position:absolute;
  top:0;
  background-color:beige;
  width:100%;
  z-index:100;
  height:100%;
  }

  </style>
</head>
<body>

<div id="left">

<?php

echo '<h1>'.$_SESSION['name'].'</h1>';

?>

<h1>HI</h1>



<a href="logOut.php">Log Out</a>
  </div>

  <div id="makeComment">

<div id="putPostHere"></div>

<form id="sendCommentForm" action="comment.php" method="get">
<textarea name="sendComment" id="sendComment"></textarea>
<input type="hidden" value="" id="sendPost" name="sendPost">
<button>Submit</button>
</form>

</div>

  <div id="middle">
 
  <?php

  
$sql ="SELECT * FROM posts INNER JOIN userFollows ON posts.userid = userFollows.whotheyfollow WHERE userFollows.userid='$active'";
$result = mysqli_query($conn,$sql);

if(mysqli_num_rows($result)>0){
  while($row=mysqli_fetch_assoc($result)){
$formId = "postValue".$row['postid'];
echo '<img class="smallH" src="headshotty.png"><h6 class="boldName">EDIT NAME</h6>';
echo "<div class='postBox'>";
echo "<form action='comment.php' method='post' id=".$formId.">";
echo "<div onclick='viewPost(".$row['postid'].")'>";
echo "<input type='hidden' name='postValue' id='postValue' value=".$row['postid'].">";
  echo "<p class='message' >".$row['message']."</p><br>";
  echo "</div>";
  echo "</form>";
  echo "<button class='thumbs' value=".$row['postid']." onclick='likeIt(this.value,".$row['likes'].")'>&#128077;</button>".$row['likes']."<button value=".$row['postid']." onclick='comment(this.value)'>Comment</button> ";
  
  echo "</div><br>";


}
}

?>



  </div>

  <div id="right">



<form id="searchForm" name="searchForm" action="results.php" method="get">

<input type="text" id="searchBar" name="searchBar" placeholder="Search Friends">


</form>



<h1>MESSAGE</h1>

<?php

$sqlL = "SELECT DISTINCT userid,usermsgid FROM msg WHERE userid=$active OR usermsgid=$active ORDER BY clockt DESC;";
$resultL = mysqli_query($conn,$sqlL);

if(mysqli_num_rows($resultL)>0){
  while($rowL=mysqli_fetch_assoc($resultL)){
    if($rowL['usermsgid']==$active){
      $usermsg =$rowL['userid'];
    }else{
      $usermsg =$rowL['usermsgid'];
    }
    $sqlLU = "SELECT * FROM users WHERE userid=$usermsg;";
    $resultLU = mysqli_query($conn,$sqlLU);
    $rowLU =mysqli_fetch_assoc($resultLU);

    if($rowL['usermsgid']==$active){
      $usermsg =$rowL['userid'];
    }else{
      $usermsg =$rowL['usermsgid'];
      //echo "<h4 onclick='viewConvo(".$usermsg.")'>".$rowLU['firstName']." ".$rowLU['lastName']."</h4><br>";

    }
    echo "<h4 onclick='viewConvo(".$usermsg.")'>".$rowLU['firstName']." ".$rowLU['lastName']."</h4><br>";
    
  }
}
?>
  </div>

<script>

//resett();
function likeIt(a,b){
  $('#middle').load('likes.php',{
  postId: a,
  likes: b
    })

}


function resett(){
  setInterval(function(){
   $('#middle').load('/path/to/server/source');
}, 5000)

}

function comment(a){
  document.getElementById('makeComment').style.visibility='visible';
  document.getElementById('sendPost').value = a;
  $('#putPostHere').load('loadPostComment.php',{
  postId: a
    })
}

function viewPost(a){
 document.getElementById('postValue'+a.toString()).submit();
}

function viewConvo(a){
 $('#right').load('loadMessages.php',{
  userMsg: a
    })
    
}


function insertMsg(a){
  var input= document.getElementById("sendMsg").value;
 $('#right').load('sendMsg.php',{
  userMsg: a,
  contents : input
    })
}


</script>
</body>

</html>