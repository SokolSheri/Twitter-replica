<html>
<?php
include('dbh.php');
session_start();
$active=$_SESSION['userid'];
$_SESSION['viewed']=0;
?>


<head>
  <meta charset="utf-8">
  <title>Notifications</title>
  <meta name="author" content="">
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link href="css/style.css" rel="stylesheet">

  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">


  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<style>

.smallH{
    position:relative;
    height: 50px;
    width: 50px;
    border-radius: 100%;
    margin-bottom: 10px;
    display:inline-block;
  }


</style>
  </head>

  
<body> 

<?php
$sql="SELECT * FROM notif WHERE userid=$active";
$result = mysqli_query($conn,$sql);

if(mysqli_num_rows($result)>0){
while($row=mysqli_fetch_assoc($result)){
$second=$row['seconduser'];
$posty=$row['postid'];
    $s="SELECT * FROM users WHERE userid=$second";
    $r = mysqli_query($conn,$s);
    $row1=mysqli_fetch_assoc($r);
    $s1="SELECT msg FROM posts WHERE postid=$posty";
    $r1=mysqli_query($conn,$s1);
    $row2=mysqli_fetch_assoc($r1);
    echo "<a href='othersPage.php?profVal=".$second."'>";
    if($row['seen']==0){
    
   echo '<img class="smallH" src="headshotty.png"><h6 class="boldName" style="color:red;">'.$row1['firstName']." ".$row1['lastName'].'</h6>';
    }else{
      echo '<img class="smallH" src="headshotty.png"><h6 class="boldName" style="color:blue;">'.$row1['firstName']." ".$row1['lastName'].'</h6>';

    }
   echo "</a>";
    if($row['notType']==1){
        echo "<p>Liked your post</p>";
    }else {
      $target=$row['pinpoint'];
      $findComment="SELECT * FROM comments WHERE commentid=$target";
      $fcresult = mysqli_query($conn,$findComment);
      $fcrow= mysqli_fetch_assoc($fcresult);

      
        echo "<p>Commented on your post -".$fcrow['messages']."</p>";
    }
    echo "<p>'".$row2['msg']."'</p>";

}
}


if($_SESSION['viewed']==0){
    $sqlU="UPDATE notif SET seen=1 WHERE userid=$active";
    $rU=mysqli_query($conn,$sqlU);
    $_SESSION['viewed']=1;
}


?>



</body>



</html>

