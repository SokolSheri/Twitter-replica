<html>
<?php
include('dbh.php');
session_start();



if($_SERVER["REQUEST_METHOD"] == "GET") {
$active=$_SESSION['userid'];
    $postid=$_GET['sendPost'];
    $message=$_GET['sendComment'];
	$sqlI = "INSERT INTO comments(postid,messages,userid) VALUES ('$postid','$message','$active')";
    $resultI = mysqli_query($conn,$sqlI);
}else{
    $active=$_SESSION['userid'];
    $postid=$_POST['postValue'];
}

?>


<head>
  <meta charset="utf-8">
  <title>Home</title>
  <meta name="author" content="">
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link href="css/style.css" rel="stylesheet">

  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">


  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

  </head>
<body> 


<?php


$sqlL ="SELECT * FROM posts WHERE postid = $postid;";
$resultL = mysqli_query($conn,$sqlL);
$rowL=mysqli_fetch_assoc($resultL);

$sqlLC ="SELECT * FROM comments WHERE postid = $postid;";
$resultLC = mysqli_query($conn,$sqlLC);




echo '<img class="smallH""><h6 class="boldName">EDIT NAME</h6>';
  echo "<p class='message'>".$rowL['message']."</p><br>";


  
  if(mysqli_num_rows($resultLC)>0){
    while($rowLC=mysqli_fetch_assoc($resultLC)){
        $userIDD = $rowLC['userid'];
        $sqlLN ="SELECT * FROM users WHERE userid = $userIDD";
$resultLN = mysqli_query($conn,$sqlLN);
$rowLN=mysqli_fetch_assoc($resultLN);
echo $rowLN['firstName']." ";
        echo $rowLC['messages']."<br>";
  
  }
  }

?>


</body>

</html>

