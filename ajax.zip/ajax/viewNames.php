

<?php

include('dbh.php');
session_start();

echo '<h4>hi</h4>';
/*
$sqlL = "SELECT usermsgid,userid FROM msg WHERE userid=$active OR usermsgid=$active ORDER BY clockt DESC;";
$resultL = mysqli_query($conn,$sqlL);

$count = mysqli_num_rows($resultL);

if($count>0){

if(mysqli_num_rows($resultL)>0){
  $usersArr = array();
  while($rowL=mysqli_fetch_assoc($resultL)){
    if($rowL['usermsgid']==$active){
      $usermsg =$rowL['userid'];
    }else{
      $usermsg =$rowL['usermsgid'];
    }
    array_push($usersArr,$usermsg);
   
  }

 $usersArr=array_unique($usersArr);
 $usersArr=array_values($usersArr);
 
}

echo "<div id='listNames'>";
echo "<hr style='width:92%;background-color:#37454D;position:absolute;left:15px;'><br>";

for($x = 0; $x < count($usersArr); $x++){
$userL =$usersArr[$x];

  $sqlLU = "SELECT * FROM users WHERE userid=$userL;";
    $resultLU = mysqli_query($conn,$sqlLU);
    $checkSeen ="SELECT * FROM msg WHERE userid=$userL AND usermsgid=$active AND seen=0";
    $sresult=mysqli_query($conn,$checkSeen);
    $counts = mysqli_num_rows($sresult);
    $rowSeen=mysqli_fetch_assoc($sresult);
    $rowLU =mysqli_fetch_assoc($resultLU);
    $newId="show".$userL;
    $newId2="hide".$userL;
    $sendMsg="sendMsg".$userL;

   

    if($counts>0){
      echo "<div class='convoNames' style='color:#1EA2F1;'id=".$newId2." onclick='viewConvo(".$userL.")'>".ucwords(strtolower($rowLU['firstName'])." ".strtolower($rowLU['lastName']))."</div>";

    }else{
    echo "<div class='convoNames' id=".$newId2." onclick='viewConvo(".$userL.")'>".ucwords(strtolower($rowLU['firstName'])." ".strtolower($rowLU['lastName']))."</div>";
    }
    echo "<div id=".$newId." style='visibility:hidden; position:absolute; bottom:0;'>";
    echo "<input type='text' id=".$sendMsg.">";
    echo "<button onclick='insertMsg(".$userL.")'>Send</button>";
    echo "</div>";
    

    
    
}

echo "</div>";


}*/



?>

