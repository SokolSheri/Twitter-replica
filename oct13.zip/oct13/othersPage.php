<?php
include('mainInclude.php');

?>

<head>
  <meta charset="utf-8">
  <title>Home</title>
  <?php
include('headerInclude.php');


?>
  </head>
<body>

<?php
include('leftInc.php');

$val = $_GET['profVal'];

$sqlName ="SELECT * FROM users WHERE userid= $val";
$resultName = mysqli_query($conn,$sqlName);
$name = mysqli_fetch_assoc($resultName);

?>

<div id='middleC'>
<h5 id="midHome"><?php
echo ucwords(strtolower($name['firstName']." ".$name['lastName']));

?></h5>
<hr class='notihr'>

<div style='position:relative;top:-20px;left:-20px;height:360px;width:820px;border-bottom:1px solid #37454D;'>
<div id='backSplash' style='height:200px;width:820px;background-color:#3D5465;'>


<img style="position:relative; top:120px;left:1em;border:4px solid #15212B; border-radius:100%;height:140px;width:140px;" src='headshotty.png'>

<?php


echo "<div id='space'>";

$sqlL ="SELECT * FROM userFollows WHERE whotheyfollow = $val AND 
userid = $active;";
$resultL = mysqli_query($conn,$sqlL);
$count = mysqli_num_rows($resultL);

if($val!=$active){
if($count ===1){
  echo "<button id='followBtn' value=".$val." style='background-color:#1EA2F1;color:#FFFFFF;' onclick='follow(this.value)'>Following</button>";
}else{
  echo "<button id='followBtn' value=".$val." style='background-color:#3D5465;border:1px solid #3D5465;color:rgb(30,162,241);' onclick='follow(this.value)'>Follow</button>";
}

}
echo "</div>";


?>
</div>





</div>
<br>
<?php






$sql = "SELECT * FROM posts WHERE userid = '$val'";
	$result = mysqli_query($conn,$sql);
    if(mysqli_num_rows($result)>0){
        while($row=mysqli_fetch_assoc($result)){
            echo "<p class='message'>".$row['msg']."</p><br>";
      }
      }




?>

</div>

<?php
include('rightInc.php');


?>
<script>
function follow(a){
  $('#space').load('loadStatus.php',{
  following: a
    })

}



</script>

</body>

</html>