<html>
<?php
include('dbh.php');
session_start();
$active=$_SESSION['userid'];

if($_SERVER["REQUEST_METHOD"] == "GET") {
$active=$_SESSION['userid'];
    $postid=$_GET['sendPost'];
    $message=$_GET['sendComment'];
	$sqlI = "INSERT INTO comments(postid,messages,userid) VALUES ('$postid','$message','$active')";
    $resultI = mysqli_query($conn,$sqlI);
    $sqlN ="SELECT * FROM comments WHERE postid=$postid AND userid=$active;";
    $resultN = mysqli_query($conn,$sqlN);
    $rowN =mysqli_fetch_assoc($resultN);
    $sendNot= $rowN['commentid'];
    $sqlFP="SELECT * FROM posts WHERE postid=$postid";
    $resultFP = mysqli_query($conn,$sqlFP);
    $rowFP =mysqli_fetch_assoc($resultFP);
    $secondaryU=$rowFP['userid'];
    $sqlNI ="INSERT INTO notif(userid,seconduser,postid,notType,seen,pinpoint) 
    VALUES('$secondaryU','$active','$postid',2,0,'$sendNot');";
    $resultNI = mysqli_query($conn,$sqlNI);
}else{
    $active=$_SESSION['userid'];
    $postid=$_POST['postValue'];
}

?>


<head>
  <meta charset="utf-8">
  <title>Home</title>
  <?php
include('headerInclude.php');


?>
  </head>
<body id='chn'> 

<div id='left'>

<div id="navi">


<ul>
<li>
<i class='fab fa-twitter' id="twit"></i>
</li>
<li>
<a href="main.php"><i class='fas fa-home' id="firstLi"></i>
Home</a>

</li>


<li>
<a href="noti.php"><i class='fas fa-bell' id="secondLi"></i>
Notifications</a>
</li>
<li>
<a href="messages.php"><i class='fas fa-inbox' id="thirdLi"></i>
Messages</a>
</li>

<li>
<i class='far fa-bookmark' id="bookLi"></i>
Bookmarks
</li>
<li>

<?php 

echo "<a href='othersPage.php?profVal=".$active."'>";

?><i class='fas fa-thumbtack' id="fourthLi"></i>



Profile</a>

</li>



<li>
<i class='far fa-list-alt' id="moreLi"></i>

More
</li>




<li id="bottomMe">
<a href="logOut.php">Log Out</a>
</li>
</ul>


</div>
</div>
<div id='middleC'>


<?php


$sqlL ="SELECT * FROM posts WHERE postid = $postid;";
$resultL = mysqli_query($conn,$sqlL);
$rowL=mysqli_fetch_assoc($resultL);

$sqlLC ="SELECT * FROM comments WHERE postid = $postid;";
$resultLC = mysqli_query($conn,$sqlLC);

echo '<img class="smallH""><h6 class="boldName">EDIT NAME</h6>';
echo '<div id="singlePost">';
echo "<h6 id='cmtView'>".$rowL['msg']."</h6><br>";
echo '</div>';

$sqlL ="SELECT * FROM posts WHERE postid = $postid;";
$resultL = mysqli_query($conn,$sqlL);
$rowLL=mysqli_fetch_assoc($resultL);

$sqlLC ="SELECT * FROM comments WHERE postid = $postid;";
$resultLC = mysqli_query($conn,$sqlLC);


  if(mysqli_num_rows($resultLC)>0){
    while($rowLC=mysqli_fetch_assoc($resultLC)){
        $userIDD = $rowLC['userid'];
        $sqlLN ="SELECT * FROM users WHERE userid = $userIDD";
$resultLN = mysqli_query($conn,$sqlLN);
$rowLN=mysqli_fetch_assoc($resultLN);

if(isset($message)){
if($rowLC['messages']==$message){
echo $rowLN['firstName']." ";
        echo $rowLC['messages']."<br>";
}else{
  echo $rowLN['firstName']." ";
        echo $rowLC['messages']."<br>";
}
  }else{
    echo $rowLN['firstName']." ";
        echo $rowLC['messages']."<br>";

  }

  echo "<hr style='background-color: #37454D'>";

}
  }

?>

</div>

<div id='right'>


</div>


</body>

</html>

