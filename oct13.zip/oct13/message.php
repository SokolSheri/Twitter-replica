<?php

include('dbh.php');
session_start();
$active=$_SESSION['userid'];


$active=$_SESSION['userid'];
$secondary = $_POST['sendFirstMsg'];
$msg= $_POST['sendMsg'];

echo $secondary;


$sql = "INSERT INTO msg(userid,usermsgid,msgC,seen) VALUES ('$active','$secondary','$msg',0)";
$result = mysqli_query($conn,$sql);

header("location:main.php");
?>