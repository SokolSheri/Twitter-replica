<?php

include('dbh.php');
session_start();

?>
<head>
  <meta charset="utf-8">
  <title>Home</title>
  <meta name="author" content="">
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link href="css/style.css" rel="stylesheet">

  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">


  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

  </head>
<body>

  <?php
$arr = explode(' ',trim($_GET['searchBar']));
$first = strtoupper($arr[0]);

$sql = "SELECT * FROM users WHERE firstName = '$first'";
	$result = mysqli_query($conn,$sql);
    if(mysqli_num_rows($result)>0){
        while($row=mysqli_fetch_assoc($result)){

    $inputty = 'profVal'.$row['userid'];
   
      echo "<form action='othersPage.php' id='".$inputty."' method='get' onclick='submitForm(this.id)'>".$row['firstName']." ".$row['lastName']."<input type='hidden' id='profVal' name='profVal' value=".$row['userid']."></form><button>Follow</button>"; 
      }
      }



?>

<script>

function submitForm(a){
    document.getElementById(a).submit();
}

</script>
</body>

</html>