<html>
<?php
include('mainInclude.php');

?>

<head>
  <title>Home</title>
  <meta charset="utf-8">
 
 <?php
include('headerInclude.php');


?>

</head>
<body>

<?php
include('leftInc.php');


?>

  <div id="coverPage">

</div>
<div id="cmtBack">
  <div id="makeComment">

  <p id='exit' onclick='xCmt()'>X</p>
  <hr class='changeColor'>

<div id="putPostHere"></div>

<hr class='changeColor'>
<form id="sendCommentForm" action="comment.php" method="get">

<textarea name="sendComment" id="sendComment" onkeydown="showColor2()" placeholder="Tweet your reply"></textarea>
<input type="hidden" value="" id="sendPost" name="sendPost">
<button id='replyBtn'>Reply</button>
</form>

</div>
</div>

</div>

<div id="coverPage2">

</div>
<div id="cmtBack2">
<div id="makeComment2">

<p id='exit' onclick='xCmtt()'>X</p>
<hr class='changeColor'>

<form id="sendMessage" action="message.php" method="post">

<textarea name="sendMsg" id="sendMsg" placeholder="Send Message"></textarea>
<input type="hidden" value="" id="sendFirstMsg" name="sendFirstMsg">
<button id='firstMsg'>Send</button>
</form>

</div>
</div>

<div id="middle3">

<h5 id="midHome">Home</h5>


</div>
<div id="middle2" >
<img class="smallH" id="inlineB"src="headshotty.png">
<form id="sendTweet" method="post" action="postTweet.php">
<textarea name="thePost" id="thePost" placeholder="What's happening?" onclick='showLine()' onkeydown="showColor()" ></textarea>
<hr id="lineUnder">
<input type="submit" value="Post" id="postBtn">

</form>

</div>

  <div id="middle">

  <?php

  
$sql ="SELECT DISTINCT msg,postid,likes,posts.userid FROM posts INNER JOIN userFollows ON posts.userid = userFollows.whotheyfollow WHERE userFollows.userid='$active' OR posts.userid='$active' ORDER BY posts.timey DESC";
//$sql ="SELECT * FROM posts INNER JOIN userFollows ON posts.userid = userFollows.whotheyfollow WHERE userFollows.userid='$active' OR posts.userid='$active' ORDER BY timey DESC";
$result = mysqli_query($conn,$sql);

if(mysqli_num_rows($result)>0){
  while($row=mysqli_fetch_assoc($result)){
$formId = "postValue".$row['postid'];
$profVal=$row['userid'];
$findName = "SELECT * FROM users WHERE userid=$profVal;";
$resultName = mysqli_query($conn,$findName);
$personRow=mysqli_fetch_assoc($resultName);
$atname=strtolower($personRow['firstName'])."".strtolower($personRow['lastName']);
$postName =ucwords(strtolower($personRow['firstName'])." ".strtolower($personRow['lastName']));
$postidd=$row['postid'];
$findComments ="SELECT * FROM comments WHERE postid=$postidd;";
$resultComments = mysqli_query($conn,$findComments);
$countC=mysqli_num_rows($resultComments);



echo "<div id='singlePost'>";
echo "<a id='aPic' href='othersPage.php?profVal=".$profVal."'>";
echo '<img class="smallH" src="headshotty.png"><p class="boldName">'.$postName.'</p>&nbsp;&nbsp; <span class="atName">@'.$atname.' </a><i id="crnrM" onclick="startMsg('.$profVal.')" class="material-icons">mail_outline</i></span>';

echo "<div class='postBox'>";
echo "<form action='comment.php' method='post' id=".$formId.">";
echo "<div onclick='viewPost(".$row['postid'].")'>";
echo "<input type='hidden' name='postValue' id='postValue' value=".$row['postid'].">";
  echo "<p class='message' >".$row['msg']."</p><br>";
  echo "</div>";
  echo "</form>";
  echo "<button class='comBtn' value=".$row['postid']." onclick='comment(this.value)'><i class='fab fa-rocketchat' id='comit'></i></button><span style='color:#8898A6'>".$countC."</span>";
  echo "<button class='rt'><i class='fas fa-retweet' id='rtBtn'>&nbsp;".rand(10,100)."</i>
  </button>";
  echo "<button class='thumbs' value=".$row['postid']." onclick='likeIt(this.value,".$row['likes'].",".$profVal.")'><i class='far fa-heart' id='likeit'></i></button><span style='color:#8898A6'>".$row['likes']."</span>";
  

 

  echo "</div><br>";
  echo "</div>";
}
}

?>

  </div>
  <?php
include('rightInc.php');


?>

<script>

//resett();
function likeIt(a,b,c){
  
  $('#middle').load('likes.php',{
  postId: a,
  likes: b,
  second:c
    })

}


function resett(){
  setInterval(function(){
   $('#middle').load('/path/to/server/source');
}, 5000)

}

function comment(a){
  document.getElementById('cmtBack').style.visibility='visible';
  document.getElementById('coverPage').style.visibility='visible';
  document.getElementById('sendPost').value = a;
  $('#putPostHere').load('loadPostComment.php',{
  postId: a
    })
}

function viewPost(a){
 document.getElementById('postValue'+a.toString()).submit();
}




function viewConvo(a){

document.getElementById('hideMsg').style.visibility="hidden";
document.getElementById("show"+a).style.visibility = 'visible';
document.getElementById('goBArr').style.visibility ='visible';


$('.convoNames').hide();

setInterval(function(){ 
  $('#showMsgHere').load('loadMessages.php',{
  userMsg: a
    })
  ; }
, 1000)

}

function upScroll(){

  var element = document.getElementById("showMsgHere");
    element.scrollTop = element.scrollHeight;
    
}

function startMsg(a){

  document.getElementById('sendFirstMsg').value = a;
  document.getElementById('cmtBack2').style.visibility='visible';
  document.getElementById('coverPage2').style.visibility='visible';
  
}
function insertMsg(a){

  var input= document.getElementById("sendMsg"+a).value;
  
 $('#showMsgHere').load('sendMsg.php',{
  userMsg: a,
  contents : input
    })
    
}



function logThis(a){
  alert(typeof(a));
}

function goBack(){
 location.reload();
}

function popToggle(a){

  if(a=='a'){
    document.getElementById('msgPop').style.height='500px';
 document.getElementById('listNames').style.visibility="visible";
 document.getElementById('upArrow').style.visibility="hidden";
 document.getElementById('downArrow').style.visibility="visible";
 document.getElementById('showMsgHere').style.visibility="visible";

 if(document.getElementById('hideMsg').style.visibility=="visible"){
  document.getElementById('hideMsg').style.visibility="hidden";
  document.getElementById('goBArr').style.visibility="visible";
 }
  }else{
    document.getElementById('downArrow').style.visibility="hidden";
 document.getElementById('msgPop').style.height='60px';
 document.getElementById('upArrow').style.visibility="visible";
 document.getElementById('downArrow').style.visibility="hidden";
 document.getElementById('listNames').style.visibility="hidden";
 document.getElementById('showMsgHere').style.visibility="hidden";
 document.getElementById('goBArr').style.visibility="hidden";
 document.getElementById('hideMsg').style.visibility="visible";
 
  }
 
}

function showLine(){
  document.getElementById('lineUnder').style.visibility="visible";
  document.getElementById('middle2').style.height="170px";
  document.getElementById('middle').style.top="35%";
}

function showColor(){
var lengthy=document.getElementById('thePost').value.length;

if(lengthy>=0){
  document.getElementById('postBtn').style.color="#FFFFFF";
  document.getElementById('postBtn').style.backgroundColor="#1EA2F1";
  document.getElementById('postBtn').style.cursor="pointer";
}

var KeyID = event.keyCode;
   switch(KeyID)
   {
      case 8:
        if(lengthy<=1){
  document.getElementById('postBtn').style.color="#8A8F94";
  document.getElementById('postBtn').style.backgroundColor="#20608E";
  document.getElementById('postBtn').style.cursor="default";
}
   }

  
}


function showColor2(){
var lengthy=document.getElementById('sendComment').value.length;

if(lengthy>=0){
  document.getElementById('replyBtn').style.color="#FFFFFF";
  document.getElementById('replyBtn').style.backgroundColor="#1EA2F1";
  document.getElementById('replyBtn').style.cursor="pointer";
}

var KeyID = event.keyCode;
   switch(KeyID)
   {
      case 8:
        if(lengthy<=1){
  document.getElementById('replyBtn').style.color="#8A8F94";
  document.getElementById('replyBtn').style.backgroundColor="#20608E";
  document.getElementById('replyBtn').style.cursor="default";
}
   }

  
}

function xCmt(){
  document.getElementById('cmtBack').style.visibility='hidden';
  document.getElementById('coverPage').style.visibility='hidden';
  document.getElementById('sendComment').value = "";

}

function xCmtt(){
  document.getElementById('cmtBack2').style.visibility='hidden';
  document.getElementById('coverPage2').style.visibility='hidden';
  document.getElementById('sendMsg').value = "";
}



</script>
</body>

</html>