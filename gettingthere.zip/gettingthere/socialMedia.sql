-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Oct 24, 2020 at 08:57 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `socialMedia`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `commentid` int(11) NOT NULL,
  `times` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `postid` int(11) NOT NULL,
  `messages` varchar(140) NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`commentid`, `times`, `postid`, `messages`, `userid`) VALUES
(1, '2020-09-23 21:21:55', 2, 's', 1),
(2, '2020-09-23 21:22:09', 2, 'ixbqw', 1),
(3, '2020-09-23 21:22:23', 3, 'wq', 1),
(4, '2020-09-23 21:23:16', 3, 'judge', 8),
(5, '2020-09-23 21:51:37', 3, 'dwq', 8),
(6, '2020-09-23 21:51:50', 3, 'dwq', 8),
(7, '2020-09-23 21:52:10', 4, 'som', 8),
(8, '2020-09-23 21:52:16', 3, 'soms', 8),
(9, '2020-09-23 21:52:29', 3, 'soms', 8),
(10, '2020-09-23 22:27:58', 3, 'soms', 8),
(11, '2020-09-23 22:28:14', 3, 'soms', 8),
(12, '2020-09-23 22:29:24', 2, 'bitch', 10),
(13, '2020-09-23 22:29:32', 3, 'bitch ass', 10),
(14, '2020-09-23 22:45:08', 1, 'nig', 10),
(15, '2020-09-23 22:45:16', 1, 'nice', 10),
(16, '2020-09-23 22:45:29', 1, 'bs', 10),
(17, '2020-09-23 22:57:15', 1, 'yo', 10),
(18, '2020-09-24 20:48:49', 1, 'new comment', 10),
(19, '2020-09-24 20:49:01', 2, 'new comment again', 10),
(20, '2020-09-28 21:40:21', 1, 'coec', 1),
(21, '2020-09-28 21:41:00', 1, 'coec', 1),
(22, '2020-09-28 21:41:09', 1, 'coec', 1),
(23, '2020-09-30 22:07:48', 2, 'bitch', 1),
(24, '2020-09-30 22:09:57', 2, 'bitch', 1),
(25, '2020-09-30 22:10:07', 2, 'bitch', 1),
(26, '2020-09-30 22:10:39', 2, 'bitch', 1),
(27, '2020-09-30 22:11:25', 4, 'yo this is great', 1),
(28, '2020-09-30 22:11:37', 4, 'new', 1),
(29, '2020-09-30 22:16:00', 7, 'you rock', 1),
(30, '2020-09-30 22:16:06', 7, 'you rock', 1),
(31, '2020-09-30 22:16:18', 4, 'you rock!!', 1),
(32, '2020-09-30 22:19:17', 4, 'me again', 1),
(33, '2020-09-30 22:19:40', 4, 'hiii', 1),
(34, '2020-09-30 22:32:54', 4, 'my boy!', 1),
(35, '2020-09-30 22:37:09', 9, 'love you dude!', 1),
(39, '2020-10-12 21:05:45', 13, 'I felt that', 1),
(40, '2020-10-12 21:08:12', 13, 'I felt that', 1),
(41, '2020-10-12 21:08:24', 13, 'es', 1),
(42, '2020-10-12 21:08:34', 13, 'es', 1),
(43, '2020-10-12 21:09:01', 13, 'es', 1),
(44, '2020-10-12 21:09:11', 13, 'es', 1),
(45, '2020-10-12 21:09:35', 13, 'es', 1),
(46, '2020-10-12 21:09:36', 13, 'es', 1),
(47, '2020-10-12 21:09:44', 13, 's', 1),
(48, '2020-10-12 21:11:25', 13, 's', 1),
(49, '2020-10-12 21:11:37', 13, 's', 1),
(50, '2020-10-12 21:11:48', 13, 's', 1),
(51, '2020-10-12 21:15:52', 13, 's', 1),
(52, '2020-10-12 21:15:54', 13, 's', 1),
(53, '2020-10-12 21:18:36', 13, 's', 1),
(54, '2020-10-12 21:19:28', 13, 's', 1),
(55, '2020-10-12 21:20:06', 13, 's', 1),
(56, '2020-10-12 21:20:38', 13, 's', 1),
(57, '2020-10-12 21:20:57', 13, 's', 1),
(58, '2020-10-12 21:24:41', 10, 'yo', 1),
(59, '2020-10-12 21:25:29', 10, 'yo', 1),
(60, '2020-10-12 21:26:13', 10, 'yo', 1),
(61, '2020-10-12 21:27:30', 27, 'y', 1),
(62, '2020-10-12 21:28:19', 27, 'y', 1),
(63, '2020-10-12 21:29:16', 27, 'y', 1),
(64, '2020-10-12 21:33:38', 15, 'yes', 1),
(65, '2020-10-12 21:33:40', 15, 'yes', 1),
(66, '2020-10-12 21:33:41', 15, 'yes', 1),
(67, '2020-10-12 21:33:41', 15, 'yes', 1),
(68, '2020-10-12 21:34:27', 15, 'yes', 1),
(69, '2020-10-12 21:35:44', 15, 'yes', 1),
(70, '2020-10-12 21:36:47', 15, 'yes', 1),
(71, '2020-10-12 21:37:39', 15, 'yes', 1),
(72, '2020-10-12 21:38:23', 15, 'yes', 1),
(73, '2020-10-12 21:38:34', 15, 'yes', 1),
(74, '2020-10-12 21:39:01', 15, 'yes', 1),
(75, '2020-10-19 18:05:04', 29, 'my comment', 1),
(76, '2020-10-19 18:05:38', 30, 'my other comm', 1),
(77, '2020-10-19 21:21:44', 31, 'you the bro', 1),
(78, '2020-10-19 21:21:52', 31, 'big fact', 1),
(79, '2020-10-19 21:21:54', 31, 'big fact', 1),
(80, '2020-10-19 21:35:31', 13, 'newest comment!', 1),
(81, '2020-10-23 17:53:01', 9, 'yo', 1),
(82, '2020-10-23 17:53:20', 9, 'boy', 1),
(83, '2020-10-23 17:53:59', 9, 'boy', 1),
(84, '2020-10-23 17:54:19', 9, 'boy', 1),
(85, '2020-10-23 17:55:12', 9, 'boy', 1),
(86, '2020-10-23 17:55:22', 9, 'boy', 1),
(87, '2020-10-23 17:55:35', 9, 'boy', 1),
(88, '2020-10-23 17:55:46', 9, 'boy', 1);

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE `likes` (
  `likeid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `postid` int(11) NOT NULL,
  `liked` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `likes`
--

INSERT INTO `likes` (`likeid`, `userid`, `postid`, `liked`) VALUES
(40, 1, 2, 1),
(41, 1, 9, 0),
(42, 1, 4, 0),
(43, 1, 11, 0),
(44, 1, 12, 1),
(45, 1, 13, 0),
(46, 1, 10, 1),
(47, 1, 14, 0),
(48, 1, 27, 0),
(49, 1, 15, 0),
(50, 1, 6, 1),
(51, 1, 30, 1),
(52, 1, 28, 1),
(53, 1, 31, 0),
(54, 1, 73, 1),
(55, 1, 71, 0),
(56, 1, 8, 0),
(57, 1, 77, 1),
(58, 1, 1, 1),
(59, 1, 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `msg`
--

CREATE TABLE `msg` (
  `messageid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `usermsgid` int(11) NOT NULL,
  `msgC` varchar(200) NOT NULL,
  `seen` int(11) NOT NULL,
  `clockt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `msg`
--

INSERT INTO `msg` (`messageid`, `userid`, `usermsgid`, `msgC`, `seen`, `clockt`) VALUES
(233, 1, 11, 'you my guy', 0, '2020-10-08 04:06:20'),
(234, 1, 8, 'judge', 1, '2020-10-08 04:06:20'),
(235, 1, 8, 'uo', 1, '2020-10-08 04:07:11'),
(236, 1, 11, 'na you my guy', 0, '2020-10-08 04:07:22'),
(237, 8, 1, 'my boy!', 1, '2020-10-08 04:08:37'),
(238, 1, 11, 'whats up my boy!', 0, '2020-10-08 04:25:01'),
(239, 1, 8, 'yo bro', 1, '2020-10-12 22:24:48'),
(240, 1, 8, 'yo', 1, '2020-10-12 22:25:53'),
(241, 8, 1, 'eee', 1, '2020-10-12 22:26:03'),
(242, 1, 8, 'p', 1, '2020-10-12 22:26:24'),
(243, 8, 1, 'forex', 1, '2020-10-12 22:26:33'),
(244, 1, 11, 'my brotha!', 0, '2020-10-12 22:28:08'),
(245, 1, 11, 'yo', 0, '2020-10-13 17:40:43'),
(246, 1, 8, 'yo', 0, '2020-10-19 20:41:39'),
(247, 1, 8, 'yo', 0, '2020-10-19 20:51:44'),
(248, 1, 11, 'my guy', 0, '2020-10-19 20:52:17'),
(249, 1, 8, 'my dog', 0, '2020-10-19 21:37:07');

-- --------------------------------------------------------

--
-- Table structure for table `notif`
--

CREATE TABLE `notif` (
  `notId` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `seconduser` int(11) NOT NULL,
  `postid` int(11) NOT NULL,
  `notType` int(11) NOT NULL,
  `seen` int(11) NOT NULL,
  `pinpoint` int(11) NOT NULL,
  `timey` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `notif`
--

INSERT INTO `notif` (`notId`, `userid`, `seconduser`, `postid`, `notType`, `seen`, `pinpoint`, `timey`) VALUES
(43, 8, 1, 9, 2, 1, 35, '2020-10-12 23:19:01'),
(44, 8, 1, 9, 2, 1, 35, '2020-10-12 23:19:01'),
(45, 8, 1, 9, 2, 1, 35, '2020-10-12 23:19:01'),
(46, 8, 1, 9, 2, 1, 35, '2020-10-12 23:19:01'),
(80, 1, 1, 13, 2, 1, 39, '2020-10-12 23:19:01'),
(81, 1, 1, 13, 2, 1, 39, '2020-10-12 23:19:01'),
(82, 1, 1, 13, 2, 1, 39, '2020-10-12 23:19:01'),
(83, 1, 1, 13, 2, 1, 39, '2020-10-12 23:19:01'),
(84, 1, 1, 13, 2, 1, 39, '2020-10-12 23:19:01'),
(85, 1, 1, 13, 2, 1, 39, '2020-10-12 23:19:01'),
(86, 1, 1, 13, 2, 1, 39, '2020-10-12 23:19:01'),
(87, 1, 1, 13, 2, 1, 39, '2020-10-12 23:19:01'),
(88, 1, 1, 13, 2, 1, 39, '2020-10-12 23:19:01'),
(89, 1, 1, 13, 2, 1, 39, '2020-10-12 23:19:01'),
(90, 1, 1, 13, 2, 1, 39, '2020-10-12 23:19:01'),
(91, 1, 1, 13, 2, 1, 39, '2020-10-12 23:19:01'),
(92, 1, 1, 13, 2, 1, 39, '2020-10-12 23:19:01'),
(93, 1, 1, 13, 2, 1, 39, '2020-10-12 23:19:01'),
(94, 1, 1, 13, 2, 1, 39, '2020-10-12 23:19:01'),
(95, 1, 1, 13, 2, 1, 39, '2020-10-12 23:19:01'),
(96, 1, 1, 13, 2, 1, 39, '2020-10-12 23:19:01'),
(97, 1, 1, 13, 2, 1, 39, '2020-10-12 23:19:01'),
(98, 1, 1, 13, 2, 1, 39, '2020-10-12 23:19:01'),
(99, 1, 1, 10, 2, 1, 58, '2020-10-12 23:19:01'),
(100, 1, 1, 10, 2, 1, 58, '2020-10-12 23:19:01'),
(101, 1, 1, 10, 2, 1, 58, '2020-10-12 23:19:01'),
(102, 1, 1, 27, 2, 1, 61, '2020-10-12 23:19:01'),
(103, 1, 1, 27, 2, 1, 61, '2020-10-12 23:19:01'),
(104, 1, 1, 27, 2, 1, 61, '2020-10-12 23:19:01'),
(105, 1, 1, 15, 2, 1, 64, '2020-10-12 23:19:01'),
(106, 1, 1, 15, 2, 1, 64, '2020-10-12 23:19:01'),
(107, 1, 1, 15, 2, 1, 64, '2020-10-12 23:19:01'),
(108, 1, 1, 15, 2, 1, 64, '2020-10-12 23:19:01'),
(109, 1, 1, 15, 2, 1, 64, '2020-10-12 23:19:01'),
(110, 1, 1, 15, 2, 1, 64, '2020-10-12 23:19:01'),
(111, 1, 1, 15, 2, 1, 64, '2020-10-12 23:19:01'),
(112, 1, 1, 15, 2, 1, 64, '2020-10-12 23:19:01'),
(113, 1, 1, 15, 2, 1, 64, '2020-10-12 23:19:01'),
(114, 1, 1, 15, 2, 1, 64, '2020-10-12 23:19:01'),
(115, 1, 1, 15, 2, 1, 64, '2020-10-12 23:19:01'),
(120, 1, 1, 6, 1, 1, 50, '2020-10-12 23:19:39'),
(121, 1, 1, 12, 1, 1, 44, '2020-10-19 17:54:34'),
(123, 1, 1, 29, 2, 1, 75, '2020-10-19 21:35:36'),
(124, 1, 1, 30, 2, 1, 76, '2020-10-19 21:35:36'),
(138, 1, 1, 31, 2, 1, 77, '2020-10-19 21:35:36'),
(139, 1, 1, 31, 2, 1, 77, '2020-10-19 21:35:36'),
(140, 1, 1, 31, 2, 1, 77, '2020-10-19 21:35:36'),
(151, 1, 1, 13, 2, 1, 39, '2020-10-19 21:35:36'),
(153, 1, 1, 28, 1, 1, 52, '2020-10-19 21:57:51'),
(158, 1, 1, 30, 1, 1, 51, '2020-10-20 17:59:32'),
(169, 11, 1, 2, 1, 0, 40, '2020-10-22 23:39:25'),
(171, 8, 1, 9, 2, 0, 35, '2020-10-23 17:53:01'),
(172, 8, 1, 9, 2, 0, 35, '2020-10-23 17:53:20'),
(173, 8, 1, 9, 2, 0, 35, '2020-10-23 17:53:59'),
(174, 8, 1, 9, 2, 0, 35, '2020-10-23 17:54:19'),
(175, 8, 1, 9, 2, 0, 35, '2020-10-23 17:55:12'),
(176, 8, 1, 9, 2, 0, 35, '2020-10-23 17:55:22'),
(177, 8, 1, 9, 2, 0, 35, '2020-10-23 17:55:35'),
(178, 8, 1, 9, 2, 0, 35, '2020-10-23 17:55:46'),
(182, 1, 1, 1, 1, 1, 58, '2020-10-24 17:28:52'),
(185, 1, 1, 77, 1, 1, 57, '2020-10-24 17:28:52'),
(187, 1, 1, 73, 1, 1, 54, '2020-10-24 17:28:52'),
(189, 11, 1, 3, 1, 0, 59, '2020-10-24 17:44:09'),
(190, 1, 1, 10, 1, 0, 46, '2020-10-24 18:01:25');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `postid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `msg` varchar(1000) NOT NULL,
  `likes` int(11) NOT NULL,
  `rts` int(11) NOT NULL,
  `timey` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`postid`, `userid`, `msg`, `likes`, `rts`, `timey`) VALUES
(1, 1, 'dont include', 2, 0, '2020-09-02 21:49:05'),
(2, 11, 'POST ID 2', 215, 0, '2020-09-30 15:05:29'),
(3, 11, 'POST ID 3', 13, 0, '2020-09-02 21:49:05'),
(4, 11, 'POST ID 4', 100, 1, '2020-09-02 21:49:39'),
(5, 1, 'this is my tweet', 1, 0, '2020-09-28 21:23:57'),
(6, 1, 'this is my tweet', 2, 0, '2020-09-28 21:27:58'),
(7, 1, 'this is me', 1, 0, '2020-09-28 21:28:11'),
(8, 1, 'yerrrrr', 1, 0, '2020-09-28 21:47:19'),
(9, 8, 'This is my first post -judgy', 0, 1, '2020-09-30 22:36:50'),
(10, 1, 'Yo', 1, 0, '2020-10-01 21:30:16'),
(11, 1, 'whats everyone doing?', 0, 0, '2020-10-01 21:30:38'),
(12, 1, 'f', 1, 0, '2020-10-01 22:06:44'),
(13, 1, 'Lorem Ipsum is simply dummy text of the printing and you are so damn special baby.you are so damn special baby. you are so damn special baby', 9, 0, '2020-10-01 22:06:47'),
(15, 1, 'You a hoe my guy', 0, 0, '2020-10-07 19:23:30'),
(27, 1, 'e', 0, 0, '2020-10-07 21:13:13'),
(28, 1, 'yo', 1, 0, '2020-10-19 17:58:42'),
(29, 1, 'yeo', 0, 0, '2020-10-19 17:58:51'),
(30, 1, 'son', 1, 0, '2020-10-19 18:02:38'),
(31, 1, 'my guy', 0, 1, '2020-10-19 18:42:31'),
(67, 1, 'idk', 0, 0, '2020-10-22 20:31:04'),
(71, 1, 'NEWWW', 0, 1, '2020-10-22 20:42:32'),
(73, 1, 'N', 1, 1, '2020-10-22 21:42:28'),
(77, 1, 'This is my first post -judgyID=9', 1, 0, '2020-10-22 22:49:59'),
(78, 8, 'POST ID 4ID=4', 0, 0, '2020-10-24 17:24:31'),
(79, 1, 'NID=73', 0, 0, '2020-10-24 17:24:50'),
(80, 1, 'NEWWWID=71', 0, 0, '2020-10-24 17:57:15');

-- --------------------------------------------------------

--
-- Table structure for table `retweets`
--

CREATE TABLE `retweets` (
  `rtid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `postid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `retweets`
--

INSERT INTO `retweets` (`rtid`, `userid`, `postid`) VALUES
(26, 1, 9),
(27, 8, 4),
(28, 1, 73),
(29, 1, 71);

-- --------------------------------------------------------

--
-- Table structure for table `userFollows`
--

CREATE TABLE `userFollows` (
  `followid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `whotheyfollow` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `userFollows`
--

INSERT INTO `userFollows` (`followid`, `userid`, `whotheyfollow`) VALUES
(19, 1, 11),
(21, 8, 11),
(22, 10, 1),
(23, 10, 11),
(25, 11, 1),
(26, 8, 1),
(29, 9, 1),
(51, 1, 8);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userid` int(11) NOT NULL,
  `firstName` varchar(100) NOT NULL,
  `lastName` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `picc` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `firstName`, `lastName`, `email`, `pass`, `picc`) VALUES
(1, 'SOKOL', 'SHERI', 'sokolsheri@gmail.com', '1234', 2),
(8, 'AARON', 'JUDGE', 'ajudge@yankees.com', '1234', 3),
(9, 'REY', 'SHERI', 'r@aol.com', '1', 1),
(10, 'NIGEL', 'HAYES', 'n@aol.com', '1', 3),
(11, 'AARON', 'HICKS', 'ahicks@yankees.com', '1234', 1),
(12, 'jon', 'jones', 'jbones@ufc.com', '1234', 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`commentid`);

--
-- Indexes for table `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`likeid`),
  ADD KEY `LikeID` (`likeid`);

--
-- Indexes for table `msg`
--
ALTER TABLE `msg`
  ADD PRIMARY KEY (`messageid`);

--
-- Indexes for table `notif`
--
ALTER TABLE `notif`
  ADD PRIMARY KEY (`notId`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`postid`),
  ADD UNIQUE KEY `PostID` (`postid`),
  ADD KEY `PostID_2` (`postid`);

--
-- Indexes for table `retweets`
--
ALTER TABLE `retweets`
  ADD PRIMARY KEY (`rtid`);

--
-- Indexes for table `userFollows`
--
ALTER TABLE `userFollows`
  ADD PRIMARY KEY (`followid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `commentid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT for table `likes`
--
ALTER TABLE `likes`
  MODIFY `likeid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `msg`
--
ALTER TABLE `msg`
  MODIFY `messageid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=250;

--
-- AUTO_INCREMENT for table `notif`
--
ALTER TABLE `notif`
  MODIFY `notId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=191;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `postid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT for table `retweets`
--
ALTER TABLE `retweets`
  MODIFY `rtid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `userFollows`
--
ALTER TABLE `userFollows`
  MODIFY `followid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
