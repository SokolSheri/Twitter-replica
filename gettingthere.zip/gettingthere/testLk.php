<?php
include('mainInclude.php');



$didlk= "SELECT postid FROM likes WHERE userid=1 AND liked=1;";
$didlkr=mysqli_query($conn,$didlk);
//$didlkarr=mysqli_fetch_assoc($didlkr);
$cLk=mysqli_num_rows($didlkr);
while($didlkarr=mysqli_fetch_assoc($didlkr)){
print_r($didlkarr);
}


?>

